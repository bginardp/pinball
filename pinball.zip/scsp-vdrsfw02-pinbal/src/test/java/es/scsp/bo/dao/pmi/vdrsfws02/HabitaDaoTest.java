package es.scsp.bo.dao.pmi.vdrsfws02;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import es.scsp.bo.model.pmi.vdrsfws02.Domicilio;
import es.scsp.bo.model.pmi.vdrsfws02.HabitaPersonaHelper;
import es.scsp.bo.model.pmi.vdrsfws02.Persona;



@ContextConfiguration(locations = {"classpath:es/scsp/bo/dao/pmi/vdrsfws02/IMI-VDRsfw02-infrastructure.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
@DirtiesContext
public class HabitaDaoTest {

	
	private static  Logger LOG = LoggerFactory.getLogger(HabitaDaoTest.class);
	
	
	private static String NIA = "00013848W";
	private static String NUMDOC = "JS19992";
	
	private static int DISTRITO = 3;
	private static int HOJA = 19;
	private static int SECCION = 1;
	
	@Autowired
    private HabitaDao habitaDao; 
	
	@Test
	public void testGetResidente() {
		
		 LOG.info("#################################");
		 LOG.info("####   testGetResidente       ###");
		 LOG.info("#################################");
		 try{
		
			 HabitaPersonaHelper hab = habitaDao.getResidente(NUMDOC, false); 

			 printPersona(hab);
			 
		 }catch(Exception e){
			 printException(e); 
		 } 
	}
	
	@Test
	public void testGetResidenteByNIA() {
		
		 LOG.info("#################################");
		 LOG.info("####   testGetResidenteByNIA  ###");
		 LOG.info("#################################");
		 try{
		
			 HabitaPersonaHelper hab = habitaDao.getResidente(NIA, true); 

			 printPersona(hab);
			 
		 }catch(Exception e){
			 printException(e); 
		 } 
	}
	
	
	
	@Test
	public void testResidentesInscripcion() {
		
		 LOG.info("#################################");
		 LOG.info("####   test Residentes Ins.   ###");
		 LOG.info("#################################");
		 try{
		
			List<HabitaPersonaHelper> habs = habitaDao.getResidentesInscripcion(DISTRITO, HOJA, SECCION);  

			 assertNotNull("----------- > No se ha devuelto un listado para la petici�n ",habs);
			
			 for(HabitaPersonaHelper h : habs){
				 printPersona(h);
			 }
			
			 
		 }catch(Exception e){
			 printException(e); 
		 }
	}
	
	@Test
	public void testGetHistoricoDomicilios(){
		
		 LOG.info("##########################################");
		 LOG.info("####   test Historico Domicilio Ins.   ###");
		 LOG.info("##########################################");
		 try{
		
			 List<Domicilio> doms = habitaDao.getHistoricoDomicilios(NIA); 

			 assertNotNull("----------- > No se ha devuelto un listado para la petici�n ",doms);
			
			 for(Domicilio d : doms){
				 
				 printDomicilio(d);
				 
			 }
			
			 
		 }catch(Exception e){
			 printException(e); 
		 }
	}
	
	

	private void printDomicilio(Domicilio d){
		LOG.info("---  ####################### ---");
		LOG.info("---  Desde {} => Hasta {}  :", d.getDesde(), d.getHasta());
		LOG.info("---  ------------------- ---");
		LOG.info("---  Domicilio Calle Id [{}] :", d.getId());
		LOG.info("---  Provincia: [{}] ", d.getProvincia().getCodigo());
		LOG.info("---  Municipio: [{}] ", d.getMunicipio().getCodigo());
		LOG.info("---  Calle: [Tipo:{}] - {}", d.getVia().getTipo(),  d.getVia().getNombre());
		LOG.info("---  Num  : [{}]  Km:[{}]", d.getNumero().getValor(), d.getKmt());
		LOG.info("---  Portal:[{}] ",   d.getPortal());
		LOG.info("---  Bloque:[{}] ",   d.getBloque());
		LOG.info("---  Escalera:[{}] ", d.getEscalera());
		LOG.info("---  Planta:[{}] ", d.getPlanta());
		LOG.info("---  Puerta:[{}] ", d.getPuerta());
	}
	
	
	
	private void printPersona(HabitaPersonaHelper h){		
		    assertNotNull("----------- > No se ha devuelto un residente para la petici�n ",h);    
		    LOG.info("---  ####################### ---");
			LOG.info("---  NIA [{}] :", h.getId());
			LOG.info("---  Nombre INE: [{}]", h.getNombreCompleto());
			LOG.info("---  Nombre: [{}]", h.getNombre());
			LOG.info("---  Ape 1: [{}] ", h.getApellido1());
			LOG.info("---  Ape 2: [{}] ", h.getApellido2());
			LOG.info("---  Fecha Nacimiento: [{}] ", h.getFechaNacimiento());
			LOG.info("---  Documento:[{}]  Digito Control:[{}]", h.getNumdoc(), h.getDigitControl());
			LOG.info("---  Tipo Documento:[{}] ", h.getTipDoc());
			LOG.info("---  Expedientes:[{}] ",h.getExpedientesAbiertos());
			LOG.info("---  ------------------- ---");
			LOG.info("---  Distrito:[{}] ",h.getDistrito());
			LOG.info("---      Hoja:[{}] ",h.getHoja());
			LOG.info("---   Secci�n:[{}] ",h.getSeccion());
			LOG.info("---  ------------------- ---");
			LOG.info("---   EXPEDIENTADO ?: [{}] ",h.estaExpedientado());
			LOG.info("---  ------------------- ---");
			Persona p = h.getPersona();
			
			LOG.info("--- SCSP  TipoDoc:[{}] NumDoc:[{}] ", p.getTipoDocumentacion(),p.getDocumentacion());
			
	}

	private void printException(Exception e){			
		 LOG.error("#################################");
		 LOG.error("#####     FALLO TEST       ######");
		 LOG.error("#################################");				
		 LOG.error("##### Orige: {}", e.toString());
		 e.printStackTrace();
		 fail(" ------------- FALLO TEST!!!! " + e.toString());
	}

	public void setHabitaDao(HabitaDao habitaDao) {
		this.habitaDao = habitaDao;
	}

}
