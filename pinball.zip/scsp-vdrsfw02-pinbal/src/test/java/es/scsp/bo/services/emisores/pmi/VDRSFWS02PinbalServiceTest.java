package es.scsp.bo.services.emisores.pmi;


import static org.junit.Assert.fail;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.w3c.dom.Document;

import es.scsp.bean.common.TipoDocumentacion;
import es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos;


@ContextConfiguration(locations = {"classpath:es/scsp/bo/services/emisores/pmi/IMI-VDRsfw02-infrastructure.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
@DirtiesContext
public class VDRSFWS02PinbalServiceTest {

	private static  Logger LOG = LoggerFactory.getLogger(VDRSFWS02PinbalServiceTest.class);
	
	@Autowired
	private VDRSFWS02PinbalService pinbalService;
	
	private  JAXBContext context; 
	
	private static String NIA = "GT00026918"; //"00013848W";
	private static String NUMDOC =  "X7827462X";//"JS19992";
	private static TipoDocumentacion TIPO_DOC =  TipoDocumentacion.NIE; //TipoDocumentacion.Pasaporte;
	
	
	
	@Before
	public void setUp() throws Exception {
		 LOG.info("##### @setUp");
		 Long t = System.currentTimeMillis();
		 context = JAXBContext.newInstance("es.scsp.bo.model.pmi.vdrsfws02");
		 LOG.info(" -- Contexto creado [{}  ms]", (System.currentTimeMillis() - t));
	}

	@Test
	public void testListadoHaitantesOk() {
	
		 LOG.info("#################################");
		 LOG.info("####   testListadoHaitantesOk ###");
		 LOG.info("#################################");
		 LOG.info(" -- Test: [{}] {} ",TIPO_DOC.name(), NUMDOC );
		try {
			
		   DatosEspecificos test =  pinbalService.getListadoHabitantes("TEST", NUMDOC, TIPO_DOC);
		   
		   printDatosEspecificos(test);
		   
		}catch (Exception ex){				
			printException(ex);
		}

	}
	
	
	@Test
	public void testListadoHaitantesNIAOk() {
	
		 LOG.info("####################################");
		 LOG.info("####   testListadoHaitantesNIAOk ###");
		 LOG.info("####################################");
		 LOG.info(" -- Test: [{}] {} ","NIA", NIA );
		try {
			
		   DatosEspecificos test =  pinbalService.getListadoHabitantes("TEST", NIA, null);
		   
		   printDatosEspecificos(test);
		   
		}catch (Exception ex){				
			printException(ex);
		}

	}
	
	
	@Test
	public void testHistoricoDomiciliosNIAOk() {
	
		 LOG.info("####################################");
		 LOG.info("####   testHistoricoDomicilios ###");
		 LOG.info("####################################");
		 LOG.info(" -- Test: [{}] {} ","NIA", NIA );
		try {
			
		   DatosEspecificos test =  pinbalService.getHistoricoDomicilios("TEST", NIA, null);
		   
		   printDatosEspecificos(test);
		   
		}catch (Exception ex){				
			printException(ex);
		}

	}
	
	
	@Test
	public void testHistoricoDomiciliosNIANack() {
	
		 LOG.info("####################################");
		 LOG.info("####   testHistoricoDomicilios ###");
		 LOG.info("####################################");
		 LOG.info(" -- Test: [{}] {} ","NIA", "kkkkkkkk" );
		try {
			
		   DatosEspecificos test =  pinbalService.getHistoricoDomicilios("TEST", "kkkkkkkk", null);
		   
		   printDatosEspecificos(test);
		   
		}catch (Exception ex){				
			printException(ex);
		}

	}
	
	

	
	@Test
	public void testHistoricoDomiciliosOk() {
	
		 LOG.info("####################################");
		 LOG.info("####   testHistoricoDomicilios ###");
		 LOG.info("####################################");
		 LOG.info(" -- Test: [{}] {} ",TIPO_DOC.name(), NUMDOC );
		try {
			
		   DatosEspecificos test =  pinbalService.getHistoricoDomicilios("TEST", NUMDOC, TIPO_DOC);
		   
		   printDatosEspecificos(test);
		   
		}catch (Exception ex){				
			printException(ex);
		}

	}

	
	
	
	 private void printDatosEspecificos( es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos datosespecificos){

			try { 
				
				Marshaller m = context.createMarshaller();
				m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
				StringWriter writer = new StringWriter();				 
				DocumentBuilder docBuilder =  DocumentBuilderFactory.newInstance().newDocumentBuilder();
				
				Document document = docBuilder.newDocument();
				m.marshal(datosespecificos, document);
				document.getDocumentElement();
				LOG.info("##################################");
				LOG.info("## Serializaci�n XML Correcta  ###");			
				LOG.info("##################################");
				
				m.marshal(datosespecificos, writer);
		    	LOG.info(writer.toString());
				
			}catch (Exception ex){				
				printException(ex);
			}
	 }
	 
	public VDRSFWS02PinbalService getPinbalService() {
			return pinbalService;
		}

	public void setPinbalService(VDRSFWS02PinbalService pinbalService) {
			this.pinbalService = pinbalService;
		}
		
	 
	 private void printException(Exception e){			
		 LOG.error("#################################");
		 LOG.error("#####     FALLO TEST       ######");
		 LOG.error("#################################");				
		 LOG.error("##### Orige: {}", e.toString());
		 e.printStackTrace();
		 fail(" ------------- FALLO TEST!!!! " + e.toString());
	}


}
