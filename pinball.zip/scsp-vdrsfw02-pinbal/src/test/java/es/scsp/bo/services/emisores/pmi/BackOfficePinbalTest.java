package es.scsp.bo.services.emisores.pmi;

import static org.junit.Assert.*;

import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.w3c.dom.Element;

import es.scsp.bean.common.Atributos;
import es.scsp.bean.common.Consentimiento;
import es.scsp.bean.common.DatosGenericos;
import es.scsp.bean.common.Emisor;
import es.scsp.bean.common.Peticion;
import es.scsp.bean.common.Respuesta;
import es.scsp.bean.common.Solicitante;
import es.scsp.bean.common.SolicitudTransmision;
import es.scsp.bean.common.Solicitudes;
import es.scsp.bean.common.TipoDocumentacion;
import es.scsp.bean.common.Titular;
import es.scsp.bean.common.Transmision;
import es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos;
import es.scsp.bo.model.pmi.vdrsfws02.Solicitud;
import es.scsp.bo.services.emisores.pmi.BackOfficeCodes.VDRSFWS02PINBAL;

@ContextConfiguration(locations = {"classpath:es/scsp/bo/services/emisores/pmi/BackOfficePinbalTest-Context.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
@DirtiesContext
public class BackOfficePinbalTest {
	
	private static String NIA = "GT00026918"; //"00013848W";
	private static String NUMDOC =  "X7827462X";//"JS19992";
	private static TipoDocumentacion TIPO_DOC =  TipoDocumentacion.NIE; //TipoDocumentacion.Pasaporte;
	
	private static  Logger LOG = LoggerFactory.getLogger(BackOfficePinbalTest.class);
	private static String codigoCertificado = "VDRSFWS02";
	private static SimpleDateFormat idFormat = new SimpleDateFormat("yyyyMMdd-HH:mm:ss.SSS");
	private static SimpleDateFormat tmstampFormat = new SimpleDateFormat("yyyyMMdd-HH:mm:ss.SSS");

	
	@Autowired
	private es.scsp.common.backoffice.BackOffice  backOffice;
	
		
	@Before
	public void setUp() throws Exception {		
		 LOG.info("#######################  @setUp");
		
	}

	@Test
	public void solicitaHistoricoDomicilios() throws Exception {
		   
		   try{
		 
		   LOG.info("##### @solicitaHistoricoDomicilios");
		 		   
		   Peticion pet = getPeticionSistema(VDRSFWS02PINBAL.HISTORICOPADRONAL.name(), "X7827462X", TipoDocumentacion.NIE, NIA);
		    
		   Respuesta respuesta = backOffice.NotificarSincrono(pet);
		   		  
		   printRespuesta( respuesta.getTransmisiones().getTransmisionDatos().get(0).getDatosEspecificos() );
		   
	     }catch(Exception e){
			printException(e);
		 }
	   }
	
	@Test
	public void solicitaHistoricoDomiciliosByDoc() throws Exception {
		   
		   try{
		 
		   LOG.info("##### @solicitaHistoricoDomicilios");
		 		   
		   Peticion pet = getPeticionSistema(VDRSFWS02PINBAL.HISTORICOPADRONAL.name(), "X7827462X", TipoDocumentacion.NIE, null);
		    
		   Respuesta respuesta = backOffice.NotificarSincrono(pet);
		   		  
		   printRespuesta( respuesta.getTransmisiones().getTransmisionDatos().get(0).getDatosEspecificos() );
		   
	     }catch(Exception e){
			printException(e);
		 }
	   }
	
	
	
	    @Test
		public void solicitaListadoHabitantes() throws Exception {
			   
			   try{
			 
			   LOG.info("##### @solicitaHistoricoDomicilios");
			 		   
			   Peticion pet = getPeticionSistema(VDRSFWS02PINBAL.LISTADOHABITANTES.name(), "X7827462X", TipoDocumentacion.NIE, null);
			    
			   Respuesta respuesta = backOffice.NotificarSincrono(pet);
			   		  
			   printRespuesta( respuesta.getTransmisiones().getTransmisionDatos().get(0).getDatosEspecificos() );
			   
		     }catch(Exception e){
				printException(e);
			 }
		   }
	    
	    
	    
	    @Test
		public void solicitaListadoHabitantesByNia() throws Exception {
			   
			   try{
			 
			   LOG.info("##### @solicitaHistoricoDomicilios");
			 		   
			   Peticion pet = getPeticionSistema(VDRSFWS02PINBAL.LISTADOHABITANTES.name(), "X7827462X", TipoDocumentacion.NIE, NIA);
			    
			   Respuesta respuesta = backOffice.NotificarSincrono(pet);
			   		  
			   printRespuesta( respuesta.getTransmisiones().getTransmisionDatos().get(0).getDatosEspecificos() );
			   
		     }catch(Exception e){
				printException(e);
			 }
		   }
	    
	
	
public void conformaDatosGenericosSolicitud(DatosGenericos datosGenericos){
		
		Solicitante solicitante = new Solicitante();
		solicitante.setIdentificadorSolicitante("CAIB");
		solicitante.setNombreSolicitante(" Consellerria de Educacion y Deportes");
		solicitante.setFinalidad("Consulta Educaci�n");
		solicitante.setConsentimiento(Consentimiento.Si );
		datosGenericos.setSolicitante(solicitante);

		Emisor emisor = new Emisor();
		emisor.setNifEmisor("12345678Z");
		emisor.setNombreEmisor("Ajuntament de Palma");
		datosGenericos.setEmisor(emisor);
		
		Transmision transmision = new Transmision();
		transmision.setCodigoCertificado("YOQUESE");
		transmision.setIdSolicitud(idFormat.format(new Date(System.currentTimeMillis())));
		datosGenericos.setTransmision(transmision);
		
	}
	
public Peticion generaPeticionSincrona(DatosGenericos datosGenericos, DatosEspecificos datosEspecificos) throws Exception {
	
	try{	
		Atributos atributos =  new Atributos();
		atributos.setCodigoCertificado(codigoCertificado);
		atributos.setIdPeticion( "CAIB-".concat(idFormat.format(new Date(System.currentTimeMillis()))));
	atributos.setTimeStamp(tmstampFormat.format(new Date(System.currentTimeMillis())));
	atributos.setNumElementos("1");			
		SolicitudTransmision laTransmision =  new SolicitudTransmision();
		laTransmision.setId(idFormat.format(new Date(System.currentTimeMillis())));
		laTransmision.setDatosGenericos(datosGenericos);
		laTransmision.setDatosEspecificos(datosEspecificos);
		ArrayList<SolicitudTransmision> solicitudTransmision = new ArrayList<SolicitudTransmision>();
		solicitudTransmision.add(laTransmision);
		Solicitudes solicitudes =  new Solicitudes();	
		solicitudes.setSolicitudTransmision(solicitudTransmision);
		Peticion peticion = new Peticion();			
		peticion.setSolicitudes(solicitudes);			
		peticion.setAtributos(atributos);			
		return peticion;
		
	}catch(Exception e){
		printException(e);
	}
	
	return null;
	
}


 private Peticion getPeticionSistema(String operacion, String numDocUser, TipoDocumentacion tipDocUser, String NIA) throws Exception{
	  
	  // a) Datos genericos
   Titular titular = new Titular();
   titular.setTipoDocumentacion(tipDocUser);
   titular.setDocumentacion(numDocUser);
   DatosGenericos datosGenericos = new DatosGenericos();
   datosGenericos.setTitular(titular);
   conformaDatosGenericosSolicitud(datosGenericos);
   
   // b) Datos especificos
	   Solicitud lasolicitud = new Solicitud();
	   
	    es.scsp.bo.model.pmi.vdrsfws02.Provincia  prov = new  es.scsp.bo.model.pmi.vdrsfws02.Provincia();
	    prov.setCodigo(BackOfficeCodes.IB_INE);		    
	    es.scsp.bo.model.pmi.vdrsfws02.Municipio  mun = new es.scsp.bo.model.pmi.vdrsfws02.Municipio();
		mun.setCodigo(BackOfficeCodes.PALMA_INE);
		lasolicitud.setProvincia(prov );//"07");
		lasolicitud.setMunicipio(mun);//"040");
	    //lasolicitud.setMunicipio(BackOfficeCodes.PALMA_INE);
	    //lasolicitud.setProvincia(BackOfficeCodes.IB_INE);
	   if(NIA != null){
		   lasolicitud.setNIA(NIA);
	   }
	  
	   lasolicitud.setTipoSolicitud(operacion);
	   DatosEspecificos datosEspecificos =  new DatosEspecificos();
	   datosEspecificos.setSolicitud(lasolicitud);
	   	   
	  return  generaPeticionSincrona( datosGenericos,  datosEspecificos);
	  
  } 	   
 
 
  private void printRespuesta( Object o) throws TransformerException{
	  
	  
	  // c) Imprimimos la respuesta (supuestamente un Element dentro de los datos espec�ficos)
   
   if( o instanceof Element){
	    LOG.info(" Resultado petici�n: \n {} ", convertElement( ( (Element) o)  ) );
   }else{
	   fail("La plataforma SCSP solo comprende un elemento XML como dato espec�fico. ");
	   }
	  
	  
  }
	
public static String convertElementToHtml(Element node) throws TransformerException {
	    Transformer t = TransformerFactory.newInstance().newTransformer();
	    t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
	    StringWriter sw = new StringWriter();
	    t.transform(new DOMSource(node), new StreamResult(sw));
	    return sw.toString();
	}
   
public static String convertElement(Element element) throws TransformerException {
	    Transformer t = TransformerFactory.newInstance().newTransformer();
	    t.setOutputProperty(OutputKeys.INDENT, "yes");
	    StringWriter sw = new StringWriter();
	    t.transform(new DOMSource(element), new StreamResult(sw));
	    return sw.toString();
}
   
private void printException(Exception e){	
	
	 LOG.error("#################################");
	 LOG.error("#####     FALLO TEST       ######");
	 LOG.error("#################################");
			
	 LOG.error("##### Orige: {}", e.toString());
	 e.printStackTrace();
	 fail(" ------------- FALLO TEST!!!! " + e.toString());
}
	
	
	
	
	

	
	
}
