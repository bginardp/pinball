package es.scsp.bo.services.emisores.pmi;

import static org.junit.Assert.*;

import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import es.scsp.bean.common.Atributos;
import es.scsp.bean.common.Consentimiento;
import es.scsp.bean.common.DatosGenericos;
import es.scsp.bean.common.Emisor;
import es.scsp.bean.common.Peticion;
import es.scsp.bean.common.Respuesta;
import es.scsp.bean.common.Solicitante;
import es.scsp.bean.common.SolicitudTransmision;
import es.scsp.bean.common.Solicitudes;
import es.scsp.bean.common.TipoDocumentacion;
import es.scsp.bean.common.Titular;
import es.scsp.bean.common.Transmision;
import es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos;
import es.scsp.bo.model.pmi.vdrsfws02.Solicitud;
import es.scsp.bo.services.emisores.pmi.BackOfficeCodes.VDRSFWS02PINBAL;

public class SerializationTests {

	private static  Logger LOG = LoggerFactory.getLogger(SerializationTests.class);
	
	private static String codigoCertificado = "VDRSFWS02";
	private static SimpleDateFormat idFormat = new SimpleDateFormat("yyyyMMdd-HH:mm:ss.SSS");
	private static SimpleDateFormat tmstampFormat = new SimpleDateFormat("yyyyMMdd-HH:mm:ss.SSS");
	
	private MOCK_BackOfficePinbal_VDRSFWS02 service = new MOCK_BackOfficePinbal_VDRSFWS02();

	
	private static JAXBContext context; 
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		 LOG.info("##### @setUpBeforeClass");
		 Long t = System.currentTimeMillis();
		// context = JAXBContext.newInstance(es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos.class);
		 context = JAXBContext.newInstance("es.scsp.bo.model.pmi.vdrsfws02");
		 LOG.info(" -- Contexto creado [{}  ms]", (System.currentTimeMillis() - t));
	}
	
		
	public void conformaDatosGenericosSolicitud(DatosGenericos datosGenericos){
		
		Solicitante solicitante = new Solicitante();
		solicitante.setIdentificadorSolicitante("CAIB");
		solicitante.setNombreSolicitante(" Consellerria de Educacion y Deportes");
		solicitante.setFinalidad("Consulta Educaci�n");
		solicitante.setConsentimiento(Consentimiento.Si );
		datosGenericos.setSolicitante(solicitante);

		Emisor emisor = new Emisor();
		emisor.setNifEmisor("12345678Z");
		emisor.setNombreEmisor("Ajuntament de Palma");
		datosGenericos.setEmisor(emisor);
		
		Transmision transmision = new Transmision();
		transmision.setCodigoCertificado("YOQUESE");
		transmision.setIdSolicitud(idFormat.format(new Date(System.currentTimeMillis())));
		datosGenericos.setTransmision(transmision);
		
	}
	
	public Peticion generaPeticionSincrona(DatosGenericos datosGenericos, DatosEspecificos datosEspecificos) throws Exception {
		
		try{	
			Atributos atributos =  new Atributos();
			atributos.setCodigoCertificado(codigoCertificado);
			atributos.setIdPeticion( "CAIB-".concat(idFormat.format(new Date(System.currentTimeMillis()))));
			atributos.setTimeStamp(tmstampFormat.format(new Date(System.currentTimeMillis())));
			atributos.setNumElementos("1");			
			SolicitudTransmision laTransmision =  new SolicitudTransmision();
			laTransmision.setId(idFormat.format(new Date(System.currentTimeMillis())));
			laTransmision.setDatosGenericos(datosGenericos);
			laTransmision.setDatosEspecificos(datosEspecificos);
			ArrayList<SolicitudTransmision> solicitudTransmision = new ArrayList<SolicitudTransmision>();
			solicitudTransmision.add(laTransmision);
			Solicitudes solicitudes =  new Solicitudes();	
			solicitudes.setSolicitudTransmision(solicitudTransmision);
			Peticion peticion = new Peticion();			
			peticion.setSolicitudes(solicitudes);			
			peticion.setAtributos(atributos);			
			return peticion;
			
		}catch(Exception e){
			printException(e);
		}
		
		return null;
		
	}
	
	
	 private Peticion getPeticionSistema(String operacion, String numDocUser, TipoDocumentacion tipDocUser, String NIA) throws Exception{
		  
		  // a) Datos genericos
		   Titular titular = new Titular();
		   titular.setTipoDocumentacion(tipDocUser);
		   titular.setDocumentacion(numDocUser);
		   DatosGenericos datosGenericos = new DatosGenericos();
		   datosGenericos.setTitular(titular);
		   conformaDatosGenericosSolicitud(datosGenericos);
		   
	  	   // b) Datos especificos
		   Solicitud lasolicitud = new Solicitud();
		   //lasolicitud.setMunicipio(BackOfficeCodes.PALMA_INE);
		   //lasolicitud.setProvincia(BackOfficeCodes.IB_INE);
		   
		    es.scsp.bo.model.pmi.vdrsfws02.Provincia  prov = new  es.scsp.bo.model.pmi.vdrsfws02.Provincia();
		    prov.setCodigo(BackOfficeCodes.IB_INE);		    
		    es.scsp.bo.model.pmi.vdrsfws02.Municipio  mun = new es.scsp.bo.model.pmi.vdrsfws02.Municipio();
			mun.setCodigo(BackOfficeCodes.PALMA_INE);
			lasolicitud.setProvincia(prov );//"07");
			lasolicitud.setMunicipio(mun);//"040");
		   
		   
		   if(NIA != null){
			   lasolicitud.setNIA(NIA);
		   }
		  
		   lasolicitud.setTipoSolicitud(operacion);
		   DatosEspecificos datosEspecificos =  new DatosEspecificos();
		   datosEspecificos.setSolicitud(lasolicitud);
		   	   
		  return  generaPeticionSincrona( datosGenericos,  datosEspecificos);
		  
	  } 	   
	 
	 
	  private void printRespuesta( Object o) throws TransformerException{
		  
		  
		  // c) Imprimimos la respuesta (supuestamente un Element dentro de los datos espec�ficos)
		   
		   if( o instanceof Element){
			    LOG.info(" Resultado petici�n: \n {} ", convertElement( ( (Element) o)  ) );
		   }else{
			   fail("La plataforma SCSP solo comprende un elemento XML como dato espec�fico. ");
		   }
		  
		  
	  }
	 
	
	   @Test
	   public void solicitaFalloHistoricoDomicilios() throws Exception {
		  
		   try{
           LOG.info("##### @solicita - FALLO - HistoricoDomicilios");
		   
		   // a) NIA genera Fallo:  12345678Z
				   
		   Peticion pet = getPeticionSistema(VDRSFWS02PINBAL.HISTORICOPADRONAL.name(), "X7827462X", TipoDocumentacion.NIE, "12345678Z");
		   	
		   
		   
		   Respuesta respuesta = service.NotificarSincrono(pet);
		   
		   printRespuesta( respuesta.getTransmisiones().getTransmisionDatos().get(0).getDatosEspecificos() );
		   
		   
		   
		 }catch(Exception e){
				printException(e);
		 }
	  }
	
	
	
	   @Test
	   public void solicitaHistoricoDomicilios() throws Exception {
		   
		   try{
		   LOG.info("##### @solicitaHistoricoDomicilios");
		   
		   // a) Se ha de verificar que si se facilita un NIA se adoptar� �ste para las peticiones al padr�n. 
				   
		   Peticion pet = getPeticionSistema(VDRSFWS02PINBAL.HISTORICOPADRONAL.name(), "X7827462X", TipoDocumentacion.NIE, "NIA-123456");
		   	   
		   // b) Se solicita al BackOffice // TODO: Por inyecci�n Spring en TEST. 
		  // BackOfficePinbal_VDRSFWS02 service = new BackOfficePinbal_VDRSFWS02();
		   
		   Respuesta respuesta = service.NotificarSincrono(pet);
		   		  
		   printRespuesta( respuesta.getTransmisiones().getTransmisionDatos().get(0).getDatosEspecificos() );
		   
	     }catch(Exception e){
			printException(e);
		 }
	   }
	
	   
	 @Test
	 public void solicitaFalloListadoHabitantes() throws Exception {
		   
		   try{
		   LOG.info("##### @solicita - FALLO - ListadoHabitantes");
		   
		  
		   // a) Se requiere la operaci�n pertinente
		   Peticion pet = getPeticionSistema(VDRSFWS02PINBAL.LISTADOHABITANTES.name(), "12345678Z", TipoDocumentacion.NIF, null);
		   
		    
		   	   
		   // b) Se solicita al BackOffice // TODO: Por inyecci�n Spring en TEST. 
		   // BackOfficePinbal_VDRSFWS02 service = new BackOfficePinbal_VDRSFWS02();
		   
		   Respuesta respuesta = service.NotificarSincrono(pet);
		   
		   // c) Imprimimos la respuesta (supuestamente un Element dentro de los datos espec�ficos)
		   
		   if( respuesta.getTransmisiones().getTransmisionDatos().get(0).getDatosEspecificos() instanceof Element){
			
			   // => Muy sencillo con org.jdom2.output.XMLOutputter
			    LOG.info(" Resultado petici�n: \n {} ", convertElement( (Element)respuesta.getTransmisiones().getTransmisionDatos().get(0).getDatosEspecificos()) );
			    
		   }else{
			   fail("La plataforma SCSP solo comprende un elemento XML como dato espec�fico. ");
		   }
		   
		   
	     }catch(Exception e){
			printException(e);
		 }
	   }
	   
   @Test
   public void solicitaListadoHabitantes() throws Exception {
	   
	   try{
	   LOG.info("##### @solicitaListadoHabitantes");
	   
	  
	   // a) Se requiere la operaci�n pertinente
	   Peticion pet = getPeticionSistema(VDRSFWS02PINBAL.LISTADOHABITANTES.name(), "X7827462X", TipoDocumentacion.NIE, null);
	   
	    
	   	   
	   // b) Se solicita al BackOffice // TODO: Por inyecci�n Spring en TEST. 
	   // BackOfficePinbal_VDRSFWS02 service = new BackOfficePinbal_VDRSFWS02();
	   
	   Respuesta respuesta = service.NotificarSincrono(pet);
	   
	   // c) Imprimimos la respuesta (supuestamente un Element dentro de los datos espec�ficos)
	   
	   if( respuesta.getTransmisiones().getTransmisionDatos().get(0).getDatosEspecificos() instanceof Element){
		
		   // => Muy sencillo con org.jdom2.output.XMLOutputter
		    LOG.info(" Resultado petici�n: \n {} ", convertElement( (Element)respuesta.getTransmisiones().getTransmisionDatos().get(0).getDatosEspecificos()) );
		    
	   }else{
		   fail("La plataforma SCSP solo comprende un elemento XML como dato espec�fico. ");
	   }
	   
	   
     }catch(Exception e){
		printException(e);
	 }
   }
	
  

	@Test
	public void testGenaraDatosEspecificosPeticion() throws Exception {
		try{
		
			Solicitud sol = new es.scsp.bo.model.pmi.vdrsfws02.Solicitud();
			//sol.setProvincia(BackOfficeCodes.IB_INE);
            //sol.setMunicipio(BackOfficeCodes.PALMA_INE);
            
            es.scsp.bo.model.pmi.vdrsfws02.Provincia  prov = new  es.scsp.bo.model.pmi.vdrsfws02.Provincia();
    	    prov.setCodigo(BackOfficeCodes.IB_INE);		    
    	    es.scsp.bo.model.pmi.vdrsfws02.Municipio  mun = new es.scsp.bo.model.pmi.vdrsfws02.Municipio();
    		mun.setCodigo(BackOfficeCodes.PALMA_INE);
    		sol.setProvincia(prov );//"07");
    		sol.setMunicipio(mun);//"040");
            
            
            //sol.setNIA("");
            sol.setTipoSolicitud(VDRSFWS02PINBAL.LISTADOHABITANTES.name());
			es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos de = new es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos();
			de.setSolicitud(sol);
			
			LOG.info("##### @testGenaraDatosEspecificosPeticion");
			LOG.info(" ---> Serializando datos especificos de petici�n ... ");
			
			
			StringWriter writer = new StringWriter();
			
			Marshaller m = context.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			m.marshal(de, writer);
	    	LOG.info(writer.toString());
			
	    	LOG.info(" <--- DE-Serializando datos especificos de petici�n ... ");
			
	    	
	    	 DocumentBuilder docBuilder =  DocumentBuilderFactory.newInstance().newDocumentBuilder();
		     Document document = docBuilder.newDocument();
		     m.marshal(de, document);
		     Element jobElement = document.getDocumentElement();
		     LOG.info(" <--- Element[{}] ",jobElement.getTagName());
	    	
	    	 Unmarshaller unmarshaller = context.createUnmarshaller();
		     es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos deEspFromXML = (es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos) unmarshaller.unmarshal(jobElement);
		    
		     LOG.info(" Objeto Creado:  {} / {} / {} / {} ",new Object[]{deEspFromXML.getSolicitud().getProvincia(), deEspFromXML.getSolicitud().getMunicipio(), deEspFromXML.getSolicitud().getTipoSolicitud(), deEspFromXML.getSolicitud().getNIA() });
		     
	    	
	    	
			LOG.info("#################################");
		
		}catch(Exception e){
			printException(e);
		}
		
	}
	
	public static String convertElementToHtml(Element node) throws TransformerException {
		    Transformer t = TransformerFactory.newInstance().newTransformer();
		    t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		    StringWriter sw = new StringWriter();
		    t.transform(new DOMSource(node), new StreamResult(sw));
		    return sw.toString();
		}
	   
	public static String convertElement(Element element) throws TransformerException {
		    Transformer t = TransformerFactory.newInstance().newTransformer();
		    t.setOutputProperty(OutputKeys.INDENT, "yes");
		    StringWriter sw = new StringWriter();
		    t.transform(new DOMSource(element), new StreamResult(sw));
		    return sw.toString();
	}
	   
	private void printException(Exception e){	
		
		 LOG.error("#################################");
		 LOG.error("#####     FALLO TEST       ######");
		 LOG.error("#################################");
				
		 LOG.error("##### Orige: {}", e.toString());
		 e.printStackTrace();
		 fail(" ------------- FALLO TEST!!!! " + e.toString());
	}
	

}
