package es.scsp.bo.services.emisores.pmi;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

private static final Log log = LogFactory.getLog(AFirmaCertificateValidator.class);

log.debug(String.format("Realizando consulta de informacion a @firma. IdAplicacion: %s. Subject: '%s'", new Object[] { this.idAplicacion, x509.getSubjectDN() }));


 
 */

import es.scsp.bean.common.ConfirmacionPeticion;
import es.scsp.bean.common.DatosGenericos;
import es.scsp.bean.common.Peticion;
import es.scsp.bean.common.Respuesta;
import es.scsp.bean.common.SolicitudTransmision;
import es.scsp.bean.common.TipoDocumentacion;
import es.scsp.bean.common.Titular;
import es.scsp.bean.common.Transmision;
import es.scsp.bean.common.TransmisionDatos;
import es.scsp.bean.common.Transmisiones;
import es.scsp.bo.services.emisores.pmi.BackOfficeCodes.SCSPERROR;
import es.scsp.bo.services.emisores.pmi.BackOfficeCodes.VDRSFWS02PINBAL;
import es.scsp.common.backoffice.BackOffice;
import es.scsp.common.exceptions.ScspException;



/**
 * @author FTVIDAL
 *
 */

public class BackOfficePinbal_VDRSFWS02 implements BackOffice{
	
	 private static Logger LOG = LoggerFactory.getLogger(BackOfficePinbal_VDRSFWS02.class);
	
	 private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
	 private static SimpleDateFormat idFormat = new SimpleDateFormat("yyyyMMdd-HH:mm:ss.SSS");

	 private VDRSFWS02PinbalService pinbalService;

	 
	 private static JAXBContext jaxbcontext;  
	 
	 private JAXBContext getJaxbContext() throws  BackOfficeException {
			if(jaxbcontext == null){
				try {
					jaxbcontext = JAXBContext.newInstance("es.scsp.bo.model.pmi.vdrsfws02");
				} catch (JAXBException e) {
					LOG.error("[E0403] Se ha producido un error muy grave al intentar crear el contexto JAXB para interpretar y serializar los mensajes XML del emisor SCSP para el tr�mite VDRSFWS02 tipo PINBAL. Este backoffice no va a poder gestionar ninguna petici�n hasta que se corrija este error.", e );
					throw new BackOfficeException(SCSPERROR.E0403);
				}
			}				
			
			return jaxbcontext;
	}

	 public Respuesta NotificarSincrono(Peticion pet) throws ScspException {

		try{
		
			String numDocUser=null;
			TipoDocumentacion tipDocUser= null;
			String idSistemaExterno=null;
			String tipSolicitud = null;
			boolean solicitudListado = false;
			es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos datosEspecificosRespuesta = null;
			Element theelement = null;
			es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos datosespecificos = null;
			
			
			//--------------------------------------------------------------------
			// 1 - Se comprueba que solo recibimos una solicitud (Modo síncrono).
			//--------------------------------------------------------------------
			//  Peticion: |---> Atributos				
			//            |---> Solicitudes
			//                        |-----------> SolicitudTransmision(N) = 1
			//
			if(pet.getSolicitudes().getSolicitudTransmision().size() > 1){
				LOG.error(" [E0415] Se ha recibido una petici�n de servicio para m�s de una solicitud ({}), es probable que el cliente del emisor peticionario est� mal configurado.",pet.getSolicitudes().getSolicitudTransmision().size() );
				throw new BackOfficeException(SCSPERROR.E0415);		
				
			}
			
			
			
			
			//--------------------------------------------------------------
			// 2  - Dilucidamos que  tipo de peticion se espera obtener.
			//--------------------------------------------------------------
            //
            //  Peticion: |---> Atributos				
			//            |---> Solicitudes
			//                        |-----------> SolicitudTransmision(N)
		    //                                           |-------------> DatosGenericos
			//                                           |-------------> DatosEspecificos
			//                                                                 |------------>Estado
			//                                                                 |------------>Resultado
			//                                                                 |------------>Solicitud
			//                                                                                  |---------->TipoSolicitud
			
			SolicitudTransmision solicitudTransmision = pet.getSolicitudes().getSolicitudTransmision().get(0); 
			
			if(solicitudTransmision.getDatosEspecificos() instanceof Element){
				theelement = (Element) solicitudTransmision.getDatosEspecificos();			
				if(theelement == null){
					LOG.error("[E0226] Se ha recibido una petici�n de servicio sin datos espec�ficos asociados. El cliente del emisor peticionario esta mal configurado y tiene errores.");
					throw new BackOfficeException(SCSPERROR.E0226, "No se han facilitado DATOS-ESPECIFICOS en la petici�n ");		
				}else{
					
					//--------------------------------------------------------------
					// 3  - De-serializamos los datos espec�ficos.
					//--------------------------------------------------------------
					
					getJaxbContext();
					Unmarshaller unmarshaller = jaxbcontext.createUnmarshaller();
					try{
						 javax.xml.bind.JAXBElement<es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos> jobElement =  unmarshaller.unmarshal(theelement,es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos.class);
						 
						 datosespecificos = jobElement.getValue();
						 
					}catch(Exception e){
						e.printStackTrace();
						LOG.error("[E0226] Se ha producido un error muy grave al intentar deserializar los datos espec�ficos de la petici�n. Probablemente haya un error de formato en la petici�n o las clases de contexto JAXB no est�n actualizadas pertinentemente.", e );
						throw new BackOfficeException(SCSPERROR.E0226, " No se han podido interpretar los datos espec�ficos.");
					}
					
				}
			}else{				
				datosespecificos = (es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos) solicitudTransmision.getDatosEspecificos();				
			}
			
			
			
			if(datosespecificos ==null || datosespecificos.getSolicitud() == null ){
				LOG.error("[E0226] La petici�n no ha facilitado unos datos especificos interpretables o una solicitud en el mensaje.");
				throw new BackOfficeException(SCSPERROR.E0226, " No se ha facilitado unos datos especificos o una solicitud sobre la cual aplicar una resoluci�n.");
			}else{
				
				tipSolicitud =  datosespecificos.getSolicitud().getTipoSolicitud(); // Supuestamente no puede ser NULL. El tipo numerado TipoSolicitud est� definido como String, lo que no genera un tipo especifico que se pueda deserializar.
				
				if( tipSolicitud.equalsIgnoreCase(VDRSFWS02PINBAL.HISTORICOPADRONAL.name())){
					solicitudListado = false;
				}else if(tipSolicitud.equalsIgnoreCase(VDRSFWS02PINBAL.LISTADOHABITANTES.name())){
					solicitudListado = true;					
				}else{
					LOG.error("[E0226] La petici�n no ha facilitado un tipo de solicitud [{}] interpretable ( HISTORICOPADRONAL / LISTADOHABITANTES ).", tipSolicitud);
					throw new BackOfficeException(SCSPERROR.E0226, " El tipo de soilicitud facilitado en la petici�n no se ha podido interpretar. Debe coincidir con: HISTORICOPADRONAL o  LISTADOHABITANTES");
				}
			}
			
			
			

			
			//------------------------------------------------------------------
			// 2  - Recabamos los datos del funcionario o entidad solicitante:
			//------------------------------------------------------------------
            //
            //  Peticion: |---> Atributos				
			//            |---> Solicitudes
			//                        |-----------> SolicitudTransmision(N)
		    //                                           |-------------> DatosGenericos
			//                                                                 |------------>Emisor
			//                                                                 |------------>Solicitante

			DatosGenericos datosGenericos = solicitudTransmision.getDatosGenericos();
			idSistemaExterno = datosGenericos.getSolicitante().getIdentificadorSolicitante();
			LOG.debug("[PMI][NotificarSincrono] Solicitante [{}] ", idSistemaExterno);
				
			
			
			//-------------------------------------------------------------------
			// 4  - Obtenemos la documentaci�n sobre la que hacer las consultas.
			//-------------------------------------------------------------------
            //
            //  Peticion: |---> Atributos				
			//            |---> Solicitudes
			//                        |-----------> SolicitudTransmision(N)
		    //                                           |-------------> DatosGenericos
			//                                                                 |------------>Titular
			//                                                                                  |--------->Documentaci�n
			//                                                                                  |--------->TipoDocumentacion
			//                                           |-------------> DatosEspecificos
			//                                                                 |------------>Estado
			//                                                                 |------------>Resultado
			//                                                                 |------------>Solicitud
			//                                                                                  |---------->NIA (0-1)
				
			Titular titular = datosGenericos.getTitular();
			numDocUser = titular.getDocumentacion();
			tipDocUser = titular.getTipoDocumentacion();
			if(datosespecificos.getSolicitud().getNIA() != null){
			 	numDocUser = datosespecificos.getSolicitud().getNIA();
				tipDocUser = null;
			}
			
			
			//------------------------------------------------------------------------
			// 5  - Se solicitan datos al padron municipal.
			//------------------------------------------------------------------------
            
			
			if(solicitudListado){
				datosEspecificosRespuesta = pinbalService.getListadoHabitantes(idSistemaExterno, numDocUser, tipDocUser);
			}else{
				datosEspecificosRespuesta = pinbalService.getHistoricoDomicilios(idSistemaExterno, numDocUser, tipDocUser);
			}
			
			datosEspecificosRespuesta.setSolicitud(datosespecificos.getSolicitud());
			
			
			try { 
				Marshaller m = getJaxbContext().createMarshaller();
				DocumentBuilder docBuilder =  DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document document = docBuilder.newDocument();
				m.marshal(datosEspecificosRespuesta, document);
				theelement = document.getDocumentElement();
				
			}catch (JAXBException ex){
				LOG.error("[getUnDomicilio]: JAXBException: Error al tramitar {} para  {} ",numDocUser,idSistemaExterno);
				LOG.error("[getUnDomicilio]: JAXBException:",  ex);
				throw new BackOfficeException(SCSPERROR.E0227, ex.toString());
			}catch (ParserConfigurationException ex){
				LOG.error("[getUnDomicilio]: ParserConfigurationException: Error al tramitar {} para  {} ",numDocUser,idSistemaExterno);
				LOG.error("[getUnDomicilio]: ParserConfigurationException:",  ex);
				throw new BackOfficeException(SCSPERROR.E0227, ex.toString());
			}
			
			
			
			
			
			
				
			//----------------------------------------------------------------------------
			// 6  - Se construye la respuesta. (1 Elemento)
			//----------------------------------------------------------------------------
	        //  Respuesta: |---> Atributos				
			//             |--->Transmisiones(N)
			//                        |-----------> TransmisionDatos
		    //                                           |-------------> Datos Genericos
			//                                           |-------------> Datos Especificos
			//                                                                  |---------------> Estado
			//                                                                  |---------------> Solicitud (la facilitada en petición)
			//                                                                  |---------------> Resultado ( ListadoHabitantes / HistorialPadronal)
				
			TransmisionDatos transmisionDatos = new TransmisionDatos();
			conformaTransmision(datosGenericos.getTransmision());
			datosGenericos.setTitular(titular);
			transmisionDatos.setDatosGenericos(datosGenericos);
			transmisionDatos.setDatosEspecificos(theelement);				
			Transmisiones transmisiones = new Transmisiones();			
			
			ArrayList<TransmisionDatos> listaTransmisionDatos = new ArrayList<TransmisionDatos>();
			listaTransmisionDatos.add(transmisionDatos);
			transmisiones.setTransmisionDatos(listaTransmisionDatos);				
			Respuesta respuesta = new Respuesta();
			respuesta.setAtributos(pet.getAtributos());				
			respuesta.setTransmisiones(transmisiones);			
			
			LOG.info("[PMI][NotificarSincrono] Respuesta generada para [{}]: {}",tipDocUser, numDocUser );
			
			return respuesta;

			
			
			
		}catch(BackOfficeException ex){			
			throw ex;			
		}catch(Exception ex){ // TODO: Eliminar macro-try-catch
			LOG.error("[E0227][NotificarSincrono]: Error incontrolado generado probablemente por un error de formato en la peticion",ex);
			throw new BackOfficeException(SCSPERROR.E0227, ex.toString());
		}
		
	
	}

	
	 private void conformaTransmision(Transmision t){
			Date timeNow = new Date(System.currentTimeMillis());
			t.setFechaGeneracion(dateFormat.format(timeNow));
			t.setIdTransmision(BackOfficeCodes.PALMA_SCSP.concat(idFormat.format(timeNow)));
	 }
		


	/**
	 * Se notifica que no existe el servicio Asincrono
	 * 
	 * @param pet Petición recibida por el emisor
	 * @throws ScspException Si ocurre una excepci�n SCSP
	 */
	public ConfirmacionPeticion NotificarAsincrono(Peticion pet) throws ScspException
	{
		throw new BackOfficeException(SCSPERROR.E0903);	
	}
	
	/**
	 * Se notifica que no existe el servicio Asincrono
	 * 
	 * @param sr Solicitud de Respuesta recibida por el emisor
	 * @throws ScspException Si ocurre una excepci�n SCSP
	 */
	public Respuesta SolicitudRespuesta( es.scsp.bean.common.SolicitudRespuesta sr) throws ScspException {

		throw new BackOfficeException(SCSPERROR.E0903);
		
	}

	public VDRSFWS02PinbalService getPinbalService() {
		return pinbalService;
	}

	public void setPinbalService(VDRSFWS02PinbalService pinbalService) {
		this.pinbalService = pinbalService;
	}

}
