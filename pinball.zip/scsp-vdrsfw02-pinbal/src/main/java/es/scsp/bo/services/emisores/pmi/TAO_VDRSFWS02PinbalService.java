package es.scsp.bo.services.emisores.pmi;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import es.scsp.bean.common.TipoDocumentacion;
import es.scsp.bo.dao.pmi.vdrsfws02.HabitaDao;
import es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos;
import es.scsp.bo.model.pmi.vdrsfws02.Domicilio;
import es.scsp.bo.model.pmi.vdrsfws02.HabitaPersonaHelper;
import es.scsp.bo.services.emisores.pmi.BackOfficeCodes.SCSPERROR;
import es.scsp.bo.services.emisores.pmi.BackOfficeCodes.SCSPSTATUS;

public class TAO_VDRSFWS02PinbalService implements VDRSFWS02PinbalService {

	
	private static Logger LOG = LoggerFactory.getLogger(TAO_VDRSFWS02PinbalService.class);
	
	private  HabitaDao habitaDao; 
	
	
	
	private HabitaPersonaHelper verificaResidente(String peticion,String numDocUser, TipoDocumentacion tipDocUser )throws ResidenteException, BackOfficeException{
		boolean esNia = false;
		
		if(tipDocUser !=null){
			
			LOG.debug("[PMI][{}] Petici�n registrada para [{}]: {}",   new Object[]{peticion, tipDocUser.name(), numDocUser} );
			
			if (tipDocUser.equals(TipoDocumentacion.CIF)){
				throw new ResidenteException(SCSPERROR.E0404);
			}
			
			numDocUser = formatDocTAO(numDocUser,tipDocUser);		
		
		}else{
			LOG.debug("[PMI][{}] Petici�n registrada para [NIA]: {}",peticion , numDocUser );
			esNia = true;
		}
		
		//--------------------------------------------------------------
		// 2  - Se comprueba si es residente:
		//--------------------------------------------------------------
		
		HabitaPersonaHelper hab = habitaDao.getResidente(numDocUser,esNia);		
		
		if(hab == null){ // => No es residente
			throw new ResidenteException(SCSPERROR.E0238);
		}else if( hab.estaExpedientado()){ // => Tiene expedientes de poblaci�n y/o est� marcado como caducado. 
			throw new ResidenteException(SCSPERROR.E0238);
		}		
		
		return hab;
	}
	
	@Override
	public DatosEspecificos getListadoHabitantes(String idSistemaExterno, String numDocUser, TipoDocumentacion tipDocUser) throws BackOfficeException {
		
		HabitaPersonaHelper hab = null;
	
		//--------------------------------------------------------------
		// 1  - Se comprueba si es residente:
		//--------------------------------------------------------------
		
		try{
			 hab = verificaResidente("getListadoHabitantes",numDocUser, tipDocUser );		
		}catch( ResidenteException e){
			return estadoError(e.getError());
		}
		
		es.scsp.bo.model.pmi.vdrsfws02.Estado estado = new es.scsp.bo.model.pmi.vdrsfws02.Estado(); 
		es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos datosespecificos = new es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos();
		es.scsp.bo.model.pmi.vdrsfws02.ListadoHabitantes listado = new es.scsp.bo.model.pmi.vdrsfws02.ListadoHabitantes();
		es.scsp.bo.model.pmi.vdrsfws02.ListadoPersonas listapersonas = new es.scsp.bo.model.pmi.vdrsfws02.ListadoPersonas();
		es.scsp.bo.model.pmi.vdrsfws02.Resultado resultado = new es.scsp.bo.model.pmi.vdrsfws02.Resultado();
	
				
		//-------------------------------------------------------------------------
		// 3  - Se obtienen todos los habitantes SIN EXPEDIENTES de la inscripcion
		//-------------------------------------------------------------------------
		
		List<HabitaPersonaHelper> habitantes = habitaDao.getResidentesInscripcion(hab.getDistrito(), hab.getHoja(), hab.getSeccion()); 

		if(habitantes.size() == 0){
			LOG.error("[PMI][getListadoHabitantes] Excepci�n muy grave par la petici�n [{}]: {}  => Se ha obtenido un residente pero no los habitantes de la inscripci�n => Fallo coherencia datos de TAO muy grave => Revisar consulta SQL de HIBERNATE generada.",tipDocUser.name(), numDocUser );
			return estadoError(SCSPERROR.E0238); // => Error muy improbable o imposible. 
		}
		
		for(HabitaPersonaHelper h : habitantes){
			
			if(!h.estaExpedientado()){
			   listapersonas.getPersona().add(h.getPersona());
			}
		}
		
		//-------------------------------------------------------------------------
		// 4  - Se a�ade la inscripci�n
		//-------------------------------------------------------------------------
	    listado.setClaveHojaPadronal(hab.getInscripcion());
		
	    //-------------------------------------------------------------------------
	  	// 5  - Se genera la respuesta con estado OK (tramitado).
	  	//-------------------------------------------------------------------------
	    
	    listado.setListadoPersonas(listapersonas);
	    estado.setCodigoEstado(SCSPSTATUS.TRAMITADO.getCod());
		estado.setLiteralError(SCSPSTATUS.TRAMITADO.getMsj());
		resultado.setListadoHabitantes(listado);
		datosespecificos.setResultado(resultado);
		datosespecificos.setEstado(estado);
		
		return datosespecificos;
	    
	}

	@Override
	public DatosEspecificos getHistoricoDomicilios(String idSistemaExterno,	String numDocUser, TipoDocumentacion tipDocUser) throws BackOfficeException {
		
		HabitaPersonaHelper hab = null;
		
		//--------------------------------------------------------------
		// 1  - Se comprueba si es residente:
		//--------------------------------------------------------------
		
		try{
			 hab = verificaResidente("getHistoricoDomicilios",numDocUser, tipDocUser );		
		}catch( ResidenteException e){
			return estadoError(e.getError());
		}
		
		es.scsp.bo.model.pmi.vdrsfws02.Estado estado = new es.scsp.bo.model.pmi.vdrsfws02.Estado(); 
		es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos datosespecificos = new es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos();
		es.scsp.bo.model.pmi.vdrsfws02.Resultado resultado = new es.scsp.bo.model.pmi.vdrsfws02.Resultado();		
		es.scsp.bo.model.pmi.vdrsfws02.HistorialPadronal  hispadron = new es.scsp.bo.model.pmi.vdrsfws02.HistorialPadronal(); 
		es.scsp.bo.model.pmi.vdrsfws02.HistoricoDomicilios  hisdomicilios = new es.scsp.bo.model.pmi.vdrsfws02.HistoricoDomicilios();
		
		
		//----------------------------------------------------------------------------
		// 3  - Se obtienen todas las residencias del historico oficial del HOST/S390
		//----------------------------------------------------------------------------	
		
		 List<Domicilio> doms = habitaDao.getHistoricoDomicilios(hab.getId());
		  
		 //----------------------------------------------------------------------------
		 // 4  - Se genera la respuesta con los datos de la consulta
		 //----------------------------------------------------------------------------	
		 
		 hisdomicilios.getDomicilio().addAll(doms);
		 hispadron.setPersona(hab.getPersona());
		 hispadron.setHistoricoDomicilios(hisdomicilios );
		 resultado.setHistorialPadronal(hispadron);
		 estado.setCodigoEstado(SCSPSTATUS.TRAMITADO.getCod());
		 estado.setLiteralError(SCSPSTATUS.TRAMITADO.getMsj());
		 datosespecificos.setResultado(resultado);
		 datosespecificos.setEstado(estado);
		 	
		 return datosespecificos;
	}
	
	
	
	private es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos estadoError(SCSPERROR error){
		 es.scsp.bo.model.pmi.vdrsfws02.Estado estado = new es.scsp.bo.model.pmi.vdrsfws02.Estado(); 
		 es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos datosespecificos = new es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos();
		 estado.setCodigoEstado(error.getCod());
		 estado.setLiteralError(error.getMsj());
		 datosespecificos.setEstado(estado);
		 return datosespecificos;
	}

	
	 
	
	        /**
			 * 
			 * Se debe adecuar el docuemtno facilitado a la nomenclatura TAO, a saber:
			 * 
			 *  a) Los pasaportes y otros ID se guardan �ntegros en TAO.
			 *  b) Los NIE-NIF-DNI se conservan sin la letra final.
			 *  c) NIF-DNI se rellenan de 0 hasta las 9 posiciones si tienen una longitud menor.
			 * 
			 * @param numDoc N�mero o valor del documento de Identidad.
			 * @param tipDoc Tipo de docuemntaci�n facilitada.
			 */
		 private String formatDocTAO( String numDoc,TipoDocumentacion tipDoc){
			 
			 if(tipDoc.equals(TipoDocumentacion.DNI) || tipDoc.equals(TipoDocumentacion.NIE) || tipDoc.equals(TipoDocumentacion.NIF)){
				 numDoc = numDoc.substring(0,numDoc.length() - 1 );
			 }
			 
			 if( tipDoc.equals(TipoDocumentacion.DNI) || tipDoc.equals(TipoDocumentacion.NIF)  ){
					while (numDoc.length() < 9){  // StringUtils.leftPad(numDoc, 9, "0");
						numDoc = "0".concat(numDoc);
					}				
			 }
			 
			 return numDoc;
		 }
		

	public HabitaDao getHabitaDao() {
		return habitaDao;
	}

	public void setHabitaDao(HabitaDao habitaDao) {
		this.habitaDao = habitaDao;
	}
	
	

}
