package es.scsp.bo.services.emisores.pmi;

import es.scsp.bean.common.TipoDocumentacion;

public interface VDRSFWS02PinbalService {

	
	public es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos getListadoHabitantes(String idSistemaExterno, String numDocUser, TipoDocumentacion  tipDocUser) throws BackOfficeException;
	
	
    public es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos getHistoricoDomicilios(String idSistemaExterno, String numDocUser, TipoDocumentacion  tipDocUser) throws BackOfficeException;
	
}
