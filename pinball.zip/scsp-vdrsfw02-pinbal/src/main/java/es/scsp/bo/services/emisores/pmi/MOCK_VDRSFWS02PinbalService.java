package es.scsp.bo.services.emisores.pmi;


import es.scsp.bean.common.TipoDocumentacion;
import es.scsp.bo.model.pmi.vdrsfws02.ClaveHojaPadronal;
import es.scsp.bo.model.pmi.vdrsfws02.HistoricoDomicilios;
import es.scsp.bo.model.pmi.vdrsfws02.ListadoPersonas;
import es.scsp.bo.model.pmi.vdrsfws02.Persona;
import es.scsp.bo.services.emisores.pmi.BackOfficeCodes.SCSPERROR;
import es.scsp.bo.services.emisores.pmi.BackOfficeCodes.SCSPSTATUS;

public class MOCK_VDRSFWS02PinbalService implements VDRSFWS02PinbalService {
	
	
	
	private es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos getUnDomicilio(String idSistemaExterno, String numDocUser, String tipDocUser) throws BackOfficeException {
		
		 es.scsp.bo.model.pmi.vdrsfws02.Estado estado = new es.scsp.bo.model.pmi.vdrsfws02.Estado(); 
		 es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos datosespecificos = new es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos();

		 //------------------------------------------------------------
		 // -1- Generamos la información pertinente
		 //------------------------------------------------------------
		 
		 if(numDocUser.trim().equalsIgnoreCase("12345678Z")){
			// Supuestamente no es residente.
		    estado.setCodigoEstado(SCSPERROR.E0238.getCod());
		    estado.setLiteralError(SCSPERROR.E0238.getMsj());
		    datosespecificos.setEstado(estado);
		    return datosespecificos;
		    
		}else{
			
			// Es residente , se facilita informacion.			
		    
			Persona persona = new Persona();
			persona.setApellido1("Apellido1");
			persona.setApellido2("Apellido2");
 		    persona.setFechaNacimiento("19790422"); // AAAAMMDD  es.scsp.bo.services.emisores.pmi
			
			if(tipDocUser == null){
				persona.setDocumentacion("12345678Z");
				persona.setTipoDocumentacion("NIF");
				persona.setNIA(numDocUser);	
				
			}else{			
				persona.setDocumentacion(numDocUser);
				persona.setTipoDocumentacion(tipDocUser);
				persona.setNIA("123456789");	
			}
			
			
			// A) Inf. de residencia (Se asume ha vivido siempre en el mismo lugar)
		    es.scsp.bo.model.pmi.vdrsfws02.Via via = new es.scsp.bo.model.pmi.vdrsfws02.Via();
		    via.setNombre("LLibertat");
		    via.setTipo("CE"); 		    
		    es.scsp.bo.model.pmi.vdrsfws02.Numero numero =  new es.scsp.bo.model.pmi.vdrsfws02.Numero();
		    numero.setValor("2");
		    
		    es.scsp.bo.model.pmi.vdrsfws02.Domicilio domicilio = new es.scsp.bo.model.pmi.vdrsfws02.Domicilio();
		    domicilio.setId("ID:-asdlkfjasdkfjalskdjfasfasdfasdfasdfasdf-");
		    domicilio.setDesde("19790422");
		    domicilio.setBloque("0A");
		    domicilio.setEscalera("02");
		    domicilio.setPlanta("03");
		    domicilio.setPuerta("C");
		    domicilio.setCodPostal("07013");
		    domicilio.setVia(via);
		    domicilio.setNumero(numero);
		    es.scsp.bo.model.pmi.vdrsfws02.Provincia  prov = new  es.scsp.bo.model.pmi.vdrsfws02.Provincia();
		    prov.setCodigo("07");		    
		    es.scsp.bo.model.pmi.vdrsfws02.Municipio  mun = new es.scsp.bo.model.pmi.vdrsfws02.Municipio();
			mun.setCodigo("040");
		    domicilio.setProvincia(prov );//"07");
			domicilio.setMunicipio(mun);//"040");
		  
		    // B) Estado OK, tramitado.  
		    estado.setCodigoEstado(SCSPSTATUS.TRAMITADO.getCod());
			estado.setLiteralError(SCSPSTATUS.TRAMITADO.getMsj());
						
			
			// C) Se genera un HistorialPadronal y el resultado.
			
			HistoricoDomicilios hisdomicilios = new HistoricoDomicilios();
			hisdomicilios.getDomicilio().add(domicilio);			
			
			es.scsp.bo.model.pmi.vdrsfws02.HistorialPadronal  hispadron = new es.scsp.bo.model.pmi.vdrsfws02.HistorialPadronal(); 
			hispadron.setPersona(persona);
			hispadron.setHistoricoDomicilios(hisdomicilios );

			es.scsp.bo.model.pmi.vdrsfws02.Resultado resultado = new es.scsp.bo.model.pmi.vdrsfws02.Resultado();
			resultado.setHistorialPadronal(hispadron);
			
			
			datosespecificos.setResultado(resultado);
			datosespecificos.setEstado(estado);
			
						
		}
			
		return datosespecificos;
	    
		
	}
	
	
	
	private es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos getListadoHab(String idSistemaExterno, String numDocUser, String tipDocUser) throws BackOfficeException {
		
	    es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos datosespecificos = new es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos();
		es.scsp.bo.model.pmi.vdrsfws02.ListadoHabitantes listado = new es.scsp.bo.model.pmi.vdrsfws02.ListadoHabitantes();
		es.scsp.bo.model.pmi.vdrsfws02.Estado estado = new es.scsp.bo.model.pmi.vdrsfws02.Estado(); 
		
		
		if(numDocUser.trim().equalsIgnoreCase("12345678Z")){
			// Supuestamente no es residente.
		    estado.setCodigoEstado(SCSPERROR.E0238.getCod());
		    estado.setLiteralError(SCSPERROR.E0238.getMsj());
		    datosespecificos.setEstado(estado);
		    return datosespecificos;
		    
		}
		
		
		
		
		Persona persona = new Persona();
		persona.setApellido1("Apellido1");
		persona.setApellido2("Apellido2");
		persona.setFechaNacimiento("19790422");
		
		
		if(tipDocUser == null){
			persona.setDocumentacion("12345678Z");
			persona.setTipoDocumentacion("NIF");
			persona.setNIA(numDocUser);	
			
		}else{			
			persona.setDocumentacion(numDocUser);
			persona.setTipoDocumentacion(tipDocUser);
			persona.setNIA("123456789");	
		}
		
		
			
		ListadoPersonas listapersonas = new ListadoPersonas() ;
		listapersonas.getPersona().add(persona);
		listado.setListadoPersonas(listapersonas);
		ClaveHojaPadronal hojapatronal = new ClaveHojaPadronal();
		hojapatronal.setDistrito("1");
		hojapatronal.setHoja("2");
		hojapatronal.setSeccion("3");
		listado.setClaveHojaPadronal(hojapatronal );
		
		// B) Estado OK, tramitado.  
	    estado.setCodigoEstado(SCSPSTATUS.TRAMITADO.getCod());
		estado.setLiteralError(SCSPSTATUS.TRAMITADO.getMsj());
		
		es.scsp.bo.model.pmi.vdrsfws02.Resultado resultado = new es.scsp.bo.model.pmi.vdrsfws02.Resultado();
		resultado.setListadoHabitantes(listado);
		
		datosespecificos.setResultado(resultado);
		datosespecificos.setEstado(estado);
		
		
		return datosespecificos;
	}
	
	
	
	
	public es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos getListadoHabitantes(String idSistemaExterno, String numDocUser, TipoDocumentacion  tipDocUser) throws BackOfficeException {
		
		if(tipDocUser == null){
			return getListadoHab( idSistemaExterno,  numDocUser,  null);
		}else{
			return getListadoHab( idSistemaExterno,  numDocUser,  tipDocUser.name());
		}
		
		
	}
	
	
    public es.scsp.bo.model.pmi.vdrsfws02.DatosEspecificos getHistoricoDomicilios(String idSistemaExterno, String numDocUser, TipoDocumentacion  tipDocUser) throws BackOfficeException {
    	if(tipDocUser == null){
    		return  getUnDomicilio( idSistemaExterno,  numDocUser,  null );
    	}else{
    		return  getUnDomicilio( idSistemaExterno,  numDocUser,  tipDocUser.name() );

    	}
	}

}
