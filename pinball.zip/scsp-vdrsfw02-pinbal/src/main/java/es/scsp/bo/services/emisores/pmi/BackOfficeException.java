package es.scsp.bo.services.emisores.pmi;

import es.scsp.bo.services.emisores.pmi.BackOfficeCodes.SCSPERROR;
import es.scsp.common.exceptions.ScspException;

public class BackOfficeException extends ScspException{

	public BackOfficeException(String message, String code) {
		super(message, code);
	}
	
	public BackOfficeException(SCSPERROR error) {
		super(error.getMsj(), error.getCod());
	}

	public BackOfficeException(SCSPERROR error, Object ... params) {
		super(error.getMsj(params), error.getCod());
	}
	
	
	private static final long serialVersionUID = -6892787826094773701L;
	
	

}
