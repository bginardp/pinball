package es.scsp.bo.dao.pmi.vdrsfws02;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import es.scsp.bo.model.pmi.vdrsfws02.HabitaPersonaHelper;
import es.scsp.bo.services.emisores.pmi.BackOfficeException;
import es.scsp.bo.services.emisores.pmi.BackOfficeCodes.SCSPERROR;


public class HabitaDao {
	
	
	private static  Logger LOG = LoggerFactory.getLogger(HabitaDao.class);
	
	private  SessionFactory sessionFactory;
	
	public HabitaDao(){}
	
	public HabitaDao(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	
	public HabitaPersonaHelper getResidente(String numDoc, boolean esNIA) throws  BackOfficeException{
		 Session session = null;
		 Query query = null;
		 try{
			 session = this.sessionFactory.openSession();
			 if(esNIA){
			     query = session.getNamedQuery("getResidenteByNIA");
			 }else{
				 query = session.getNamedQuery("getResidente");
			 }
			 
			 query.setString("numdoc", numDoc);			
			 HabitaPersonaHelper p  = (HabitaPersonaHelper) query.uniqueResult();
			 return p ;				
		 }catch(HibernateException ex){
			  LOG.error("[HabitaDao.getResidente]: Error Base de datos; ",ex);
			  throw new BackOfficeException(SCSPERROR.E0501, SCSPERROR.E0501.getMsj(ex.getCause().toString()));
		 }finally {
			   try{
	              session.close();
			   }catch(HibernateException e ){
				  LOG.error("Error cerrando la sesion Hibernate ... ");
			   }catch(NullPointerException e){
				  LOG.error("La sesion de Hibernate es NULL !!! error de configuracion de BBDD ");
			   }
	     }
		 
	}
	
	public List<HabitaPersonaHelper> getResidentesInscripcion(int distrito, int hoja, int seccion)throws  BackOfficeException{
		 Session session = null;
		 try{
			 session = this.sessionFactory.openSession();
			 Query query = session.getNamedQuery("getResidentesInscripcion");
			 query.setInteger("distrito", distrito);
			 query.setInteger("hoja", hoja);
			 query.setInteger("seccion", seccion);			 
			 @SuppressWarnings("unchecked")
			 List<HabitaPersonaHelper> doms = (List<HabitaPersonaHelper>) query.list();
			 return doms;	
		 }catch(HibernateException ex){
			  LOG.error("[HabitaDao.getResidentesInscripcion]: Error Base de datos; ",ex);
			  throw new BackOfficeException(SCSPERROR.E0501, SCSPERROR.E0501.getMsj(ex.getCause().toString()));
		 }finally {
			   try{
	              session.close();
			   }catch(HibernateException e ){
				  LOG.error("Error cerrando la sesion Hibernate ... ");
			   }catch(NullPointerException e){
				  LOG.error("La sesion de Hibernate es NULL !!! error de configuracion de BBDD ");
			   }
	     }
		
	}
	
	
	public List<es.scsp.bo.model.pmi.vdrsfws02.Domicilio> getHistoricoDomicilios(String nia)throws  BackOfficeException{
		 Session session = null;
		 try{
			  session = this.sessionFactory.openSession();
			 Query query = session.getNamedQuery("getHistoricoDomicilios");
			 query.setString("nia", nia);				 
			 @SuppressWarnings("unchecked")
			 List<es.scsp.bo.model.pmi.vdrsfws02.Domicilio> doms =  query.list();
			 return doms;	
		 }catch(HibernateException ex){
			  LOG.error("[HabitaDao.getHistoricoDomicilios]: Error Base de datos; ",ex);
			  throw new BackOfficeException(SCSPERROR.E0501, SCSPERROR.E0501.getMsj(ex.getCause().toString()));
		 }finally {
			   try{
	              session.close();
			   }catch(HibernateException e ){
				  LOG.error("Error cerrando la sesion Hibernate ... ");
			   }catch(NullPointerException e){
				  LOG.error("La sesion de Hibernate es NULL !!! error de configuracion de BBDD ");
			   }
	     }
		
	}
	

}
