package es.scsp.bo.model.pmi.vdrsfws02;

import java.util.Date;

import es.scsp.bean.common.TipoDocumentacion;
import es.scsp.bo.services.emisores.pmi.BackOfficeCodes;


public class HabitaPersonaHelper {
	
	
	
	private String id;  // El NIA equivalente a IDNAYUN o CON del sujeto. 
	private String numdoc;
	private String digitControl;
	private int tipDoc;
	private String nombreCompleto; // Con particulas.
	private String nombre;
	private String apellido1;
	private String apellido2;	
	private int expedientesAbiertos;
	private Date   fechaNacimiento;
	private int  distrito;
	private int seccion;
	private int hoja;
	private String lastTipMov; // Sirve para controlar si tiene un expediente de caduciddad habierto.

	
	
	public boolean estaExpedientado(){
		if(this.expedientesAbiertos > 0 || (this.lastTipMov !=null && this.lastTipMov.trim().equalsIgnoreCase(BackOfficeCodes.CLAVE_CADUCIDAD)) ){
			return true;
		}else{
			return false;
		}
	}
	
	public Persona getPersona(){
		
		Persona p = new Persona();
		p.setNombre(this.nombre);
		p.setApellido1(this.apellido1);
		p.setApellido2(this.apellido2);
		p.setFechaNacimiento(BackOfficeCodes.SCSP_DATEFORMAT.format(this.fechaNacimiento));
		p.setNIA(this.id);
		p.setDocumentacion("");		
		switch(this.tipDoc){
		  case 1:p.setTipoDocumentacion(TipoDocumentacion.NIF.name()); break; // 1 (DNI)
		  case 2: p.setTipoDocumentacion(TipoDocumentacion.Pasaporte.name()); break; // 2 (Pasaporte)
		  case 3: p.setTipoDocumentacion(TipoDocumentacion.NIE.name()); break; // 3 (Tarjeta Residencia)
		  default: p.setTipoDocumentacion(null); // 0 (sin documento) y 4 (Otros)		
		}	
		
		if(this.digitControl == null){
			p.setDocumentacion( this.numdoc);
		}else{
			p.setDocumentacion( this.numdoc.concat(this.digitControl));
		}
		return p;
	}
	
	public ClaveHojaPadronal getInscripcion(){
		ClaveHojaPadronal c = new ClaveHojaPadronal();
		c.setDistrito(String.valueOf(this.distrito));
		c.setHoja(String.valueOf(this.hoja));
		c.setSeccion(String.valueOf(this.seccion));
		return c;
	}
	
	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}

	public String getNumdoc() {
		return numdoc;
	}


	public void setNumdoc(String numdoc) {
		this.numdoc = numdoc;
	}

	public String getDigitControl() {
		return digitControl;
	}


	public void setDigitControl(String digitControl) {
		this.digitControl = digitControl;
	}

	public int getTipDoc() {
		return tipDoc;
	}

	public void setTipDoc(int tipDoc) {
		this.tipDoc = tipDoc;
	}

	public String getNombreCompleto() {
		return nombreCompleto;
	}

	public void setNombreCompleto(String nombreCompleto) {
		this.nombreCompleto = nombreCompleto;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

   public String getApellido1() {
		return apellido1;
	}




	public void setApellido1(String apellido1) {
		this.apellido1 = apellido1;
	}




	public String getApellido2() {
		return apellido2;
	}




	public void setApellido2(String apellido2) {
		this.apellido2 = apellido2;
	}




	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}




	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}




	public int getExpedientesAbiertos() {
		return expedientesAbiertos;
	}




	public void setExpedientesAbiertos(int expedientesAbiertos) {
		this.expedientesAbiertos = expedientesAbiertos;
	}




	public int getDistrito() {
		return distrito;
	}




	public void setDistrito(int distrito) {
		this.distrito = distrito;
	}




	public int getSeccion() {
		return seccion;
	}




	public void setSeccion(int seccion) {
		this.seccion = seccion;
	}




	public int getHoja() {
		return hoja;
	}




	public void setHoja(int hoja) {
		this.hoja = hoja;
	}




	public HabitaPersonaHelper(){
		super();
	}
	
	public String getLastTipMov() {
		return lastTipMov;
	}

	public void setLastTipMov(String lastTipMov) {
		this.lastTipMov = lastTipMov;
	}

	
	
}
