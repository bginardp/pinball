package es.scsp.bo.services.emisores.pmi;

import es.scsp.bo.services.emisores.pmi.BackOfficeCodes.SCSPERROR;

public class ResidenteException extends Exception {

	private SCSPERROR error;
	
	public ResidenteException(SCSPERROR e){
		super(e.getMsj());
		this.error=e;		
	}
	
	public SCSPERROR getError() {
		return error;
	}

	private static final long serialVersionUID = -5810539320690727646L;
	
}
