package es.scsp.bo.model;

import java.io.Serializable;

public class TransaccionSCSP implements Serializable{

     private static final long serialVersionUID = 1000364540510499001L;

     private String id;	 
	 private Integer valor;
	 private String  repuesta;
	 private String  errorSOAP;
	 private String  errorTRAMITE;
	 private String  errorMensaje;
	 
	
	public TransaccionSCSP(){super();}
	 
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Integer getValor() {
		return valor;
	}
	public void setValor(Integer valor) {
		this.valor = valor;
	}
	public String getRepuesta() {
		return repuesta;
	}
	public void setRepuesta(String repuesta) {
		this.repuesta = repuesta;
	}
	public String getErrorSOAP() {
		return errorSOAP;
	}
	public void setErrorSOAP(String errorSOAP) {
		this.errorSOAP = errorSOAP;
	}
	public String getErrorTRAMITE() {
		return errorTRAMITE;
	}
	public void setErrorTRAMITE(String errorTRAMITE) {
		this.errorTRAMITE = errorTRAMITE;
	}
	public String getErrorMensaje() {
		return errorMensaje;
	}
	public void setErrorMensaje(String errorMensaje) {
		this.errorMensaje = errorMensaje;
	}
	 
	 
}
