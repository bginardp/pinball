package es.scsp.bo.dao.pmi;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import es.scsp.bo.model.TransaccionSCSP;
import es.scsp.bo.services.emisores.pmi.BackOfficeGenericException;
import es.scsp.bo.services.emisores.pmi.BackOfficeGenericCodes.SCSPERROR;

public class BackOfficeDao {
	
	private static  Logger LOG = LoggerFactory.getLogger(BackOfficeDao.class);
	
	private final static String GENERIC_QUERY="solicitudSCSP";
	private final static String P_CODCER="codcertificado";
	private final static String P_DATESP="datosespecificos";
	private  SessionFactory sessionFactory;
	
	public BackOfficeDao(){super();}
	
	public BackOfficeDao(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	public TransaccionSCSP procesaPeticion(String codcertificado, String xmlpeticion) throws  BackOfficeGenericException{
			 Session session = null;
			 Query query = null;
			 try{
				 session = this.sessionFactory.openSession();
				 query = session.getNamedQuery(GENERIC_QUERY);
				 query.setString(P_CODCER, codcertificado);	
				 query.setString(P_DATESP, xmlpeticion);
				 List<TransaccionSCSP> ls = (List<TransaccionSCSP>) query.list();
				 
				 if(ls !=null){
					 return ls.get(0);
				 }else{
					 return null;
				 }
				 
				// TransaccionSCSP p  = (TransaccionSCSP) query.uniqueResult();
				// return p ;				
			 }catch(HibernateException ex){
				  LOG.error("[HabitaDao.getResidente]: Error Base de datos; ",ex);
				  throw new BackOfficeGenericException(SCSPERROR.E0501, SCSPERROR.E0501.getMsj(ex.getCause().toString()));
			 }finally{
				   try{
		              session.close();
				   }catch(HibernateException e ){
					  LOG.error("Error cerrando la sesion Hibernate ... ");
				   }catch(NullPointerException e){
					  LOG.error("La sesion de Hibernate es NULL !!! error de configuracion de BBDD ");
				   }
		     }			 
	}
}
