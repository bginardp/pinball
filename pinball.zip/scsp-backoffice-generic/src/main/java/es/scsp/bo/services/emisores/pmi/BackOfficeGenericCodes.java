package es.scsp.bo.services.emisores.pmi;

import java.text.SimpleDateFormat;

public class BackOfficeGenericCodes {
	
public static final String PALMA_SCSP = "PMI";

public static final String PALMA_INE = "040";

public static final String IB_INE = "07";

public static SimpleDateFormat SCSP_DATEFORMAT = new SimpleDateFormat("yyyyMMdd"); // Formato SCSP: AAAAMMDD

public  static final String CLAVE_CADUCIDAD ="XC"; 

public  static final String CLAVE_HASTA_HOY="15730101";
	
	/**
     *   Conjunto de errores tipificados por defecto para las excepciones SCTCP.
     *  
     *   Son eqivalentes a las <link>es.scsp.common.exceptions.ScspExceptionConstants</link> aunque �stos disponen de m�s de 100 errores.
     *   
     *   T�picamente se traslasan aqu� los errores tipificados en la tabla: scsp_codigo_error del esquema de los emisores.<br/>
     *   
     *   Cada error tiene un mensaje y un c�digo �nico de cuatro d�gitos.</br>
     *   
     *   Como pertenece a un servicio de integraci�n del estado, de momento no se le proporciona soporte multilingue con  las anotaciones de Calion (ch.qos.cal10n.LocaleData)
     *
     *
     * */
	
//@BaseName("es.scsp.bo.services.emisores.pmi.ERRORES_SCP")
//@LocaleData( defaultCharset="ISO-8859-1", value = { @Locale("es"), @Locale("ca") })) 
public static enum SCSPERROR {
	

/** c�digo: 0101	Error al contactar con el servicio Web especificado %s %s                                                                          */    E0101 ("0101","Error al contactar con el servicio Web especificado %s %s" ),
/** c�digo: 0102	Comunicaci�n sin respuesta %s %s                                                                                                   */    E0102 ("0102","Comunicaci�n sin respuesta %s %s"  ),
/** c�digo: 0103	Servidor responde mensaje que no es XML                                                                                            */    E0103 ("0103","Servidor responde mensaje que no es XML "  ),
/** c�digo: 0201	Error al generar el identificativo de petici�n                                                                                     */    E0201 ("0201","Error al generar el identificativo de petici�n"  ),
/** c�digo: 0202	Error al insertar la petici�n %s                                                                                                   */    E0202 ("0202","Error al insertar la petici�n %s"),
/** c�digo: 0203	Error al actualizar el estado %s %s                                                                                                */    E0203 ("0203","Error al actualizar el estado %s %s"  ),
/** c�digo: 0204	Error al actualizar el TER  %s %s                                                                                                  */    E0204 ("0204","Error al actualizar el TER  %s %s" ),
/** c�digo: 0205	Error al actualizar la fecha de �ltimo sondeo %s %s                                                                                */    E0205 ("0205","Error al actualizar la fecha de último sondeo %s %s" ),
/** c�digo: 0206	Error al actualizar el fichero de respuesta %s                                                                                     */    E0206 ("0206","Error al actualizar el fichero de respuesta %s" ),
/** c�digo: 0207	Error al recuperar el estado de la petici�n %s                                                                                     */    E0207 ("0207","Error al recuperar el estado de la petici�n %s" ),
/** c�digo: 0208	Fichero de respuesta caducado  %s                                                                                                  */    E0208 ("0208","Fichero de respuesta caducado  %s"  ),
/** c�digo: 0209	Error al comprobar las transmisiones insertadas %s                                                                                 */    E0209 ("0209","Error al comprobar las transmisiones insertadas %s"),
/** c�digo: 0210	Error al recuperar el CIF del Organismo Requirente %s                                                                              */    E0210 ("0210","Error al recuperar el CIF del Organismo Requirente %s"),
/** c�digo: 0211	Error al recuperar el TER  %s                                                                                                      */    E0211 ("0211","Error al recuperar el TER  %s"),
/** c�digo: 0212	Error al descomponer el fichero de petici�n  %s                                                                                    */    E0212 ("0212","Error al descomponer el fichero de petici�n  %s"),
/** c�digo: 0213	Error al recuperar peticiones pendientes. %s                                                                                       */    E0213 ("0213","Error al recuperar peticiones pendientes. %s"),
/** c�digo: 0214	Error al insertar las transmisiones. %s                                                                                            */    E0214 ("0214","Error al insertar las transmisiones. %s"  ),
/** c�digo: 0215	Error al actualizar el campo error %s  %s                                                                                          */    E0215 ("0215","Error al actualizar el campo error %s  %s"  ),
/** c�digo: 0216	Error al actualizar el mensaje de respuesta  %s                                                                                    */    E0216 ("0216","Error al actualizar el mensaje de respuesta  %s"),
/** c�digo: 0217	Error al recuperar la CADUCIDAD  %s                                                                                                */    E0217 ("0217","Error al recuperar la CADUCIDAD  %s"),
/** c�digo: 0218	Error al descomponer el mensaje de petici�n   %s                                                                                   */    E0218 ("0218","Error al descomponer el mensaje de petici�n%s"  ),
/** c�digo: 0219	Error al recuperar el fichero de respuesta   %s                                                                                    */    E0219 ("0219","Error al recuperar el fichero de respuesta%s"),
/** c�digo: 0220	Error al enviar la alarma de la petici�n   %s                                                                                      */    E0220 ("0220","Error al enviar la alarma de la petici�n%s"  ),
/** c�digo: 0221	Error al comprobar las peticiones pendientes.                                                                                      */    E0221 ("0221","Error al comprobar las peticiones pendientes."),
/** c�digo: 0222	Error al borrar las respuestas caducadas.                                                                                          */    E0222 ("0222","Error al borrar las respuestas caducadas." ),
/** c�digo: 0223	Error al escribir el fichero de errores  %s                                                                                        */    E0223 ("0223","Error al escribir el fichero de errores  %s" ),
/** c�digo: 0224	Error al borrar el fichero de error  %s                                                                                            */    E0224 ("0224","Error al borrar el fichero de error  %s"  ),
/** c�digo: 0225	Se ha alcanzado el n�mero m�ximo de respuestas para la petici�n servidas.%s                                                        */    E0225 ("0225","Se ha alcanzado el n�mero m�ximo de respuestas para la petici�n servidas.%s"  ),
/** c�digo: 0226	Error al parsear el XML %s                                                                                                         */    E0226 ("0226","Error al parsear el XML %s"),
/** c�digo: 0227	Error al generar la respuesta. %s                                                                                                  */    E0227 ("0227","Error al generar la respuesta. %s " ),
/** c�digo: 0229	La petici�n ya ha sido tramitada o ya existe en el sistema, est� repetida                                                          */    E0229 ("0229","La petici�n ya ha sido tramitada o ya existe en el sistema, est� repetida"  ),
/** c�digo: 0230	El timestamp de la petici�n debe ser v�lido y de hoy o de ayer. %s                                                                 */    E0230 ("0230","El timestamp de la petici�n debe ser v�lido y de hoy o de ayer. %s"  ),
/** c�digo: 0231	Documento Incorrecto %s                                                                                                            */    E0231 ("0231","Documento Incorrecto %s"),
/** c�digo: 0232	Documento con m�s de un identificador.%s                                                                                           */    E0232 ("0232","Documento con m�s de un identificador.%s" ),
/** c�digo: 0233	Titular no identificado.                                                                                                           */    E0233 ("0233","Titular no identificado."),
/** c�digo: 0234	%s. No se ha encontrado en base de datos configuraci�n alguna para alg�n certificado asociado al c�digo pasado por par�metro.      */    E0234 ("0234","%s. No se ha encontrado en base de datos configuraci�n alguna para alg�n certificado asociado al c�digo pasado por par�metro."),
/** c�digo: 0235	El NIF del certificado no coincide con el tag NifSolicitante.                                                                      */    E0235 ("0235","El NIF del certificado no coincide con el tag NifSolicitante."  ),
/** c�digo: 0236	Consentimiento del solicitante inv�lido. %s                                                                                        */    E0236 ("0236","Consentimiento del solicitante inv�lido. %s" ),
/** c�digo: 0237	Tag NumElementos inv�lido. %s                                                                                                      */    E0237 ("0237","Tag NumElementos inv�lido. %s"),
/** c�digo: 0238	Informaci�n no disponible.                                                                                                         */    E0238 ("0238","Informaci�n no disponible." ),
/** c�digo: 0239	Error al tratar los datos espec�ficos. %s                                                                                          */    E0239 ("0239","Error al tratar los datos espec�ficos. %s"),
/** c�digo: 0240	Formato de documento inv�lido para NIE                                                                                             */    E0240 ("0240","Formato de documento inv�lido para NIE "),
/** c�digo: 0241	Certificado o Respuesta Caducada                                                                                                   */    E0241 ("0241","Certificado o Respuesta Caducada" ),
/** c�digo: 0242	Error Gen�rico de la AEAT                                                                                                          */    E0242 ("0242","Error Gen�rico de la AEAT  "),
/** c�digo: 0243	No todas las solicitudes de transmisi�n hacen referencia al mismo certificado especificado en nodo <Atributos>                     */    E0243 ("0243","No todas las solicitudes de transmisión hacen referencia al mismo certificado especificado en nodo <Atributos>" ),
/** c�digo: 0246	Error con los id transmision asignados por el backoffice.  O todas las transmisiones poseen identificador o ninguna.%s             */    E0246 ("0246","Error con los id transmision asignados por el backoffice.  O todas las transmisiones poseen identificador o ninguna.%s" ),
/** c�digo: 0247	Error Tag TER no valido                                                                                                            */    E0247 ("0247","Error Tag TER no valido" ),
/** c�digo: 0248	Error respuesta con un numero de transmisiones diferente a las solicitudes incluidas en la petici�n %s                             */    E0248 ("0248","Error respuesta con un numero de transmisiones diferente a las solicitudes incluidas en la petici�n %s"  ),
/** c�digo: 0301	Organismo no autorizado   %s %s                                                                                                    */    E0301 ("0301","Organismo no autorizado%s %s"),
/** c�digo: 0302	Certificado caducado  %s                                                                                                           */    E0302 ("0302","Certificado caducado  %s"  ),
/** c�digo: 0303	Certificado revocado  %s                                                                                                           */    E0303 ("0303","Certificado revocado  %s"  ),
/** c�digo: 0304	El DN del Organismo Requirente no coincide con el almacenado para la petici�n  %s                                                  */    E0304 ("0304","El DN del Organismo Requirente no coincide con el almacenado para la petici�n  %s"  ),
/** c�digo: 0305	Firma no v�lida %s                                                                                                                 */    E0305 ("0305","Firma no v�lida %s"  ),
/** c�digo: 0306	Error al generar la firma del mensaje %s                                                                                           */    E0306 ("0306","Error al generar la firma del mensaje %s" ),
/** c�digo: 0307	No se ha encontrado el nodo firma.                                                                                                 */    E0307 ("0307","No se ha encontrado el nodo firma."  ),
/** c�digo: 0308	Error al obtener la firma del mensaje SOAP %s                                                                                      */    E0308 ("0308","Error al obtener la firma del mensaje SOAP %s"  ),
/** c�digo: 0309	Error general al verificar el certificado :%s                                                                                      */    E0309 ("0309","Error general al verificar el certificado :%s"  ),
/** c�digo: 0310	No se ha podido verificar la CA del certificado.%s                                                                                 */    E0310 ("0310","No se ha podido verificar la CA del certificado.%s"),
/** c�digo: 0311	No se ha encontrado el certificado firmante en el documento XML.%s                                                                 */    E0311 ("0311","No se ha encontrado el certificado firmante en el documento XML.%s"  ),
/** c�digo: 0312	NIF del emisor especificado no coincide con el Organismo Emisor                                                                    */    E0312 ("0312","NIF del emisor especificado no coincide con el Organismo Emisor"),
/** c�digo: 0313	Error al Cifrar o descifrar el mensaje                                                                                             */    E0313 ("0313","Error al Cifrar o descifrar el mensaje" ),
/** c�digo: 0401	La estructura del fichero recibido no corresponde con el esquema.%s                                                                */    E0401 ("0401","La estructura del fichero recibido no corresponde con el esquema.%s" ),
/** c�digo: 0402	Falta informar campo obligatorio %s %s                                                                                             */    E0402 ("0402","Falta informar campo obligatorio %s %s"  ),
/** c�digo: 0403	Imposible obtener el contenido XML del mensaje SOAP.%s                                                                             */    E0403 ("0403","Imposible obtener el contenido XML del mensaje SOAP.%s"  ),
/** c�digo: 0404	Tipo de documento del titular inv�lido.                                                                                            */    E0404 ("0404","Tipo de documento del titular inv�lido."),
/** c�digo: 0405	Error al transformar el XML en texto plano a partir de la plantilla %s.                                                            */    E0405 ("0405","Error al transformar el XML en texto plano a partir de la plantilla %s."),
/** c�digo: 0406	Contenido del mensaje SOAP no esperado                                                                                             */    E0406 ("0406","Contenido del mensaje SOAP no esperado" ),
/** c�digo: 0415    El n�mero de solicitudes es mayor que uno. Ejecute el servicio en modo as�ncrono si est� habilitado.                               */    E0415 ("0415","El n�mero de solicitudes es mayor que uno. Ejecute el servicio en modo as�ncrono."),
/** c�digo: 0501	Error de Base de Datos: %s                                                                                                         */    E0501 ("0501","Error de Base de Datos: %s"),
/** c�digo: 0502	Error de sistema:  %s                                                                                                              */    E0502 ("0502","Error de sistema:  %s"  ),
/** c�digo: 0901	Servicio no disponible                                                                                                             */    E0901 ("0901","Servicio no disponible"  ),
/** c�digo: 0902	Modo s�ncrono no soportado.                                                                                                        */    E0902 ("0902","Modo s�ncrono no soportado."),
/** c�digo: 0903	Modo as�ncrono no soportado.                                                                                                       */    E0903 ("0903","Modo as�ncrono no soportado."  ),
/** c�digo: 0904	Error general Indefinido %s                                                                                                        */    E0904 ("0904","Error general Indefinido %s"  );


private final String msj;
private final String id;
SCSPERROR(String codigo, String mensaje){ this.msj = mensaje; this.id = codigo;}
public String getCod(){return id;}
public String getMsj(){return msj;}
public String getMsj(Object ... params){
	   try{
			return String.format(getMsj(), params);
		}catch (Exception e1) {
			e1.printStackTrace();
		}
	   return getMsj();
}

}


public static enum SCSPSTATUS {	
	
	PENDIENTE("0001","Pendiente"),
	ENPROCESO("0002","En proceso"),
	TRAMITADO("0003","Tramitada"),
	POLLING  ("0004","En proceso Polling");
	
	private final String msj;
	private final String id;
	SCSPSTATUS (String codigo, String mensaje){ this.msj = mensaje; this.id = codigo;}
	public String getCod(){return id;}
	public String getMsj(){return msj;}
}
	
public static enum VDRSFWS02PINBAL{
	LISTADOHABITANTES,
	HISTORICOPADRONAL
}
	

}
