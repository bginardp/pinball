package es.scsp.bo.services.emisores.pmi;

import es.scsp.bo.services.emisores.pmi.BackOfficeGenericCodes.SCSPERROR;
import es.scsp.common.exceptions.ScspException;

public class BackOfficeGenericException extends ScspException{

	public BackOfficeGenericException(String message, String code) {
		super(message, code);
	}
	
	public BackOfficeGenericException(SCSPERROR error) {
		super(error.getMsj(), error.getCod());
	}

	public BackOfficeGenericException(SCSPERROR error, Object ... params) {
		super(error.getMsj(params), error.getCod());
	}
	
	
	private static final long serialVersionUID = -6892787826094773701L;
	
	

}

