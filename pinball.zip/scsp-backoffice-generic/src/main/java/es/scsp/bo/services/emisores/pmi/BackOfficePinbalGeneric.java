package es.scsp.bo.services.emisores.pmi;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

import es.scsp.bean.common.Atributos;
import es.scsp.bean.common.ConfirmacionPeticion;
import es.scsp.bean.common.DatosGenericos;
import es.scsp.bean.common.Estado;
import es.scsp.bean.common.Peticion;
import es.scsp.bean.common.Respuesta;
import es.scsp.bean.common.SolicitudTransmision;
import es.scsp.bean.common.Titular;
import es.scsp.bean.common.Transmision;
import es.scsp.bean.common.TransmisionDatos;
import es.scsp.bean.common.Transmisiones;
import es.scsp.bo.model.TransaccionSCSP;
import es.scsp.bo.services.emisores.pmi.BackOfficeGenericCodes.SCSPERROR;
import es.scsp.common.backoffice.BackOffice;
import es.scsp.common.exceptions.ScspException;
import es.scsp.utils.TransformerXML;

public class BackOfficePinbalGeneric implements BackOffice{


	 private static Logger LOG = LoggerFactory.getLogger(BackOfficePinbalGeneric.class);
	 private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
	 private static SimpleDateFormat idFormat = new SimpleDateFormat("yyyyMMdd-HH:mm:ss.SSS");

	 private es.scsp.bo.dao.pmi.BackOfficeDao  daobackoffice;
	 
	@Override
	public Respuesta NotificarSincrono(Peticion pet) throws ScspException {
		
		try{
			
		Element pet_xml = null;	
		Element res_xml = null;	
		SolicitudTransmision solicitudTransmision = null;
		String idSistemaExterno=null;
		String codCertificado=null;
		Titular titular = null;
		String aux = null;
		TransaccionSCSP ts = null;
		Atributos resAtributos = null;
		
		//--------------------------------------------------------------------
		// 1 - Se comprueba que solo recibimos una solicitud (Modo s�ncrono). 
		//--------------------------------------------------------------------
		//  Peticion: |---> Atributos				
		//            |---> Solicitudes
		//                        |-----------> SolicitudTransmision(N) = 1
		//
		if(pet.getSolicitudes().getSolicitudTransmision().size() > 1){
			LOG.error(" [E0415] Se ha recibido una petici�n de servicio para m�s de una solicitud ({}), es probable que el cliente del emisor peticionario est� mal configurado.",pet.getSolicitudes().getSolicitudTransmision().size() );
			throw new BackOfficeGenericException(SCSPERROR.E0415);
		}
		
		//--------------------------------------------------------------
		// 2  - Dilucidamos que  tipo de peticion se espera obtener.
		//--------------------------------------------------------------
        //
        //  Peticion: |---> Atributos				
		//            |---> Solicitudes
		//                        |-----------> SolicitudTransmision(N)
	    //                                           |-------------> DatosGenericos
		//                                           |-------------> DatosEspecificos
		//                                                                 |------------>Estado
		//                                                                 |------------>Resultado
		//                                                                 |------------>Solicitud
		//                                                                                  |---------->TipoSolicitud
		
		
		solicitudTransmision = pet.getSolicitudes().getSolicitudTransmision().get(0); 
		
		if(solicitudTransmision.getDatosEspecificos() instanceof Element){
			pet_xml = (Element) solicitudTransmision.getDatosEspecificos();			
			if(pet_xml == null){
				LOG.error("[E0226] Se ha recibido una petici�n de servicio sin datos espec�ficos asociados. El cliente del emisor peticionario esta mal configurado y tiene errores.");
				throw new BackOfficeGenericException(SCSPERROR.E0226, "No se han facilitado DATOS-ESPECIFICOS en la petici�n ");		
			}
		}else{			
			throw new BackOfficeGenericException(SCSPERROR.E0226,"Se esperaba un objeto 'org.w3c.dom.Element' pero se ha recibido otro tipo inesperado." );
		}
		
		
		//------------------------------------------------------------------
		// 3  - Recabamos los datos del funcionario o entidad solicitante:
		//------------------------------------------------------------------
        //
        //  Peticion: |---> Atributos				
		//            |---> Solicitudes
		//                        |-----------> SolicitudTransmision(N)
	    //                                           |-------------> DatosGenericos
		//                                                                 |------------>Emisor
		//                                                                 |------------>Solicitante
		//

		DatosGenericos datosGenericos = solicitudTransmision.getDatosGenericos();
		idSistemaExterno = datosGenericos.getSolicitante().getIdentificadorSolicitante();
		codCertificado = datosGenericos.getTransmision().getCodigoCertificado();
		titular = datosGenericos.getTitular();
		aux = TransformerXML.elementToString(pet_xml);
		resAtributos = pet.getAtributos();
		if(resAtributos != null){
			LOG.info("[{}] Solicitante [{}] Atributos: idPet[{}] certificado[{}] Elementos[{}] TimeStamp[{}]  ", new Object[]{ this.hashCode(),idSistemaExterno,resAtributos.getIdPeticion(), resAtributos.getCodigoCertificado(), resAtributos.getNumElementos(), resAtributos.getTimeStamp() } );
		}else{
			throw new BackOfficeGenericException(SCSPERROR.E0226," No se han facilitado atributos asociados a la petici�n (/Peticion/Atributos). Fallo en la petici�n." );	

		}
		
			
		//----------------------------------------------------------------------------------------------
		// 4  - Se facilita el XML recibido al PLSQL y se construye el XML a facilitar en la respuesta:
		//----------------------------------------------------------------------------------------------
		
		try{
	    
		ts = daobackoffice.procesaPeticion(codCertificado, aux );
		
	    if(ts.getErrorSOAP()!=null){
	    	throw new BackOfficeGenericException(ts.getErrorMensaje(), ts.getErrorSOAP());
	    }else{	    		    
	    	res_xml = TransformerXML.string2Element(ts.getRepuesta());  
	    	Estado estat = new Estado();
	    	estat.setCodigoEstado(ts.getErrorTRAMITE());
	    	estat.setLiteralError(ts.getErrorMensaje());
	    	resAtributos.setEstado(estat);	    	
	    }
		
		}finally{
			if(ts!=null){
				LOG.info("[{}] Solicitante [{}]  Tramite[{}]  Pet: {} \n Res: {}  ", new Object[]{ this.hashCode(),idSistemaExterno,codCertificado,aux,ts.getRepuesta()} );
			}else{
				LOG.info("[{}] Solicitante [{}]  Tramite[{}]  Pet: {}  -- SIN REPSUESTA, fallo en el acceso a datos.  ", new Object[]{ this.hashCode(),idSistemaExterno,codCertificado,aux} );
			}

		}
		
		//----------------------------------------------------------------------------
		// 5  - Se construye la respuesta. (1 Elemento)
		//----------------------------------------------------------------------------
        //  Respuesta: |---> Atributos				
		//             |--->Transmisiones(N)
		//                        |-----------> TransmisionDatos
	    //                                           |-------------> Datos Genericos
		//                                           |-------------> Datos Especificos
		//                                                                  |---------------> Estado
		//                                                                  |---------------> Solicitud (la facilitada en petici�n)
		//                                                                  |---------------> Resultado ( ListadoHabitantes / HistorialPadronal)
		
		TransmisionDatos transmisionDatos = new TransmisionDatos();
		conformaTransmision(datosGenericos.getTransmision());
		datosGenericos.setTitular(titular);
		transmisionDatos.setDatosGenericos(datosGenericos);
		transmisionDatos.setDatosEspecificos(res_xml);				
		Transmisiones transmisiones = new Transmisiones();		
		ArrayList<TransmisionDatos> listaTransmisionDatos = new ArrayList<TransmisionDatos>();
		listaTransmisionDatos.add(transmisionDatos);
		transmisiones.setTransmisionDatos(listaTransmisionDatos);				
		Respuesta respuesta = new Respuesta();
		respuesta.setAtributos(resAtributos);				
		respuesta.setTransmisiones(transmisiones);	
		return respuesta;
		
		
	    }catch(BackOfficeGenericException ex){			
			throw ex;			
		}catch(Exception ex){ // TODO: Eliminar macro-try-catch
			LOG.error("[E0227][NotificarSincrono]: Error incontrolado generado probablemente por un error de formato en la peticion",ex);
			throw new BackOfficeGenericException(SCSPERROR.E0227, ex.toString());
		}
		
	}
	
	
	
	
	
	/**
	 * Se notifica que no existe el servicio Asincrono
	 * 
	 * @param pet Petici�n recibida por el emisor
	 * @throws ScspException Si ocurre una excepci�n SCSP
	 */
	
	@Override
	public ConfirmacionPeticion NotificarAsincrono(Peticion pet) throws ScspException {
		throw new BackOfficeGenericException(SCSPERROR.E0903);	
	}
	
	
	/**
	 * Se notifica que no existe el servicio Asincrono
	 * 
	 * @param sr Solicitud de Respuesta recibida por el emisor
	 * @throws ScspException Si ocurre una excepci�n SCSP
	 */
	
	@Override
	public Respuesta SolicitudRespuesta( es.scsp.bean.common.SolicitudRespuesta arg) throws ScspException {
		throw new BackOfficeGenericException(SCSPERROR.E0903);
	}
	

	 private void conformaTransmision(Transmision t){
			Date timeNow = new Date(System.currentTimeMillis());
			t.setFechaGeneracion(dateFormat.format(timeNow));
			t.setIdTransmision(BackOfficeGenericCodes.PALMA_SCSP.concat(idFormat.format(timeNow)));
	 }





	public es.scsp.bo.dao.pmi.BackOfficeDao getDaobackoffice() {
		return daobackoffice;
	}





	public void setDaobackoffice(es.scsp.bo.dao.pmi.BackOfficeDao daobackoffice) {
		this.daobackoffice = daobackoffice;
	}
	
}
