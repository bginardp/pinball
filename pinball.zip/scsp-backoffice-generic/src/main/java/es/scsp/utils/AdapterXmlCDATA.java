package es.scsp.utils;

import javax.xml.bind.annotation.adapters.XmlAdapter;

	
public class AdapterXmlCDATA extends XmlAdapter<String, String> {
	 
	private static String CDATASECTION = "<![CDATA[%s]]>";
	
	
	
	/**
	 *  
	 * Sirve para intentar trasladar un elemento XML complejo como un elemento CDTA.
	 * 
	 *   Se debe poner una anotaci�n como la que sigue en la transcripci�n. 
	 
	     @XmlJavaTypeAdapter(AdapterXmlCDATA.class)
         protected String description;
	  
	 * */
	
    @Override
    public String marshal(String value) throws Exception {
    	if(value == null){
    		return "";
    	}else{
    		return  String.format(CDATASECTION, value);  
    	}
      
    }
    @Override
    public String unmarshal(String value) throws Exception {
        return value;
    }
 
}


