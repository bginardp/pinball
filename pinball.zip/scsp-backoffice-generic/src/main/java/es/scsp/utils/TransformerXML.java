package es.scsp.utils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

public class TransformerXML {

	public static String elementToString(Element element) throws TransformerException {
	    Transformer t = TransformerFactory.newInstance().newTransformer();
	    t.setOutputProperty(OutputKeys.INDENT, "no");
	    t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
	    StringWriter sw = new StringWriter();
	    t.transform(new DOMSource(element), new StreamResult(sw));
	    return sw.toString();
    }
	
	
	public static Document string2Document(String xml) throws IOException, SAXException, ParserConfigurationException {

	    if (xml == null)
	    return null;

	    return inputStream2Document(new ByteArrayInputStream(xml.getBytes()));

	}
	
	public static Element string2Element(String xml) throws IOException, SAXException, ParserConfigurationException {

	    if (xml == null)
	    return null;

	    return inputStream2Document(new ByteArrayInputStream(xml.getBytes())).getDocumentElement();

	}

	public static Document inputStream2Document(InputStream inputStream) throws IOException, SAXException, ParserConfigurationException {
	    DocumentBuilderFactory newInstance = DocumentBuilderFactory.newInstance();
	    newInstance.setNamespaceAware(true);
	    Document parse = newInstance.newDocumentBuilder().parse(inputStream);
	    return parse;
	}
	
}
