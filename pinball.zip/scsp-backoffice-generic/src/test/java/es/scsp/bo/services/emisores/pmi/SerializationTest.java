package es.scsp.bo.services.emisores.pmi;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;

import es.scsp.utils.TransformerXML;

public class SerializationTest {

	private static  Logger LOG = LoggerFactory.getLogger(SerializationTest.class);
	
	private String XML_PET = null;
	
	
	@Before
	public void setUp() throws Exception {		
		 LOG.info("####################### ");
		 LOG.info("####### @setUp OK! ");
		 LOG.info("####################### ");		
	}

	@Test
	public void test() {
	    try{
		 StringBuilder sb = new StringBuilder();
		 sb.append("<DatosEspecificos xmlns=\"http://intermediacion.redsara.es/scsp/esquemas/datosespecificos\">");
		 sb.append("<Solicitud><MunicipioSolicitud>008</MunicipioSolicitud>");
		 sb.append("<Titular><DatosPersonales>");
		 sb.append("<Nombre>Mickey</Nombre>");
		 sb.append("<Apellido1>Mouse</Apellido1>");
		 sb.append("</DatosPersonales></Titular>");
		 sb.append("<ProvinciaSolicitud>07</ProvinciaSolicitud>");
		 sb.append("</Solicitud></DatosEspecificos>");	 
		 XML_PET=sb.toString();
		 
		 LOG.info("####### @setUp  Datos STRING: {}", XML_PET);
		 
		 Document d =  TransformerXML.string2Document(XML_PET);
		 
		 LOG.info("####### @exec  Ok: >{}<", d.getDocumentElement().getNodeName());
		 		 
		 LOG.info("####### @exec  toString: {}", TransformerXML.elementToString(d.getDocumentElement()));
		 
		 LOG.info("####### @end "); 
		 
	 }catch(Exception e){
			printException(e);
	 }
  }
	
	
	
	private void printException(Exception e){			
		 LOG.error("#################################");
		 LOG.error("#####     FALLO TEST       ######");
		 LOG.error("#################################");				
		 LOG.error("##### Orige: {}", e.toString());
		 e.printStackTrace();
		 fail(" ------------- FALLO TEST!!!! " + e.toString());
	}
	
}
