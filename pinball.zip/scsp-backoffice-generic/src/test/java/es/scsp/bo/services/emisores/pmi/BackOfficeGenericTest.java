package es.scsp.bo.services.emisores.pmi;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.File;
import java.util.Scanner;

import es.scsp.bo.model.TransaccionSCSP;



@ContextConfiguration(locations = {"classpath:GenericSpringContext.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
@DirtiesContext
public class BackOfficeGenericTest {

	private static  Logger LOG = LoggerFactory.getLogger(BackOfficeGenericTest.class);
	
	private String COD_CERTIFICADO= null;
	private String XML_PET = null;
	
	
	@Autowired
	private es.scsp.bo.dao.pmi.BackOfficeDao  daobackoffice;
	
	
	
	@Before
	public void setUp() throws Exception {		
		 LOG.info("####################### ");
		 LOG.info("####### @setUp OK! ");
		 LOG.info("####################### ");		
	}
	
	
	//@Test
	public void testFileToSCDCPAJU() {
		 try{ 
		 COD_CERTIFICADO="SCDCPAJU";
		 XML_PET= new Scanner( TransaccionSCSP.class.getResourceAsStream("/Test.xml") ).useDelimiter("\\A").next();
		 callBackOffice();		
		 }catch(Exception e){
				printException(e);
		 }
	}
	
	@Test
	public void testSCDCPAJU() {
		 COD_CERTIFICADO="SCDCPAJU";
		 StringBuilder sb = new StringBuilder();
		 sb.append("<DatosEspecificos xmlns=\"http://intermediacion.redsara.es/scsp/esquemas/datosespecificos\">");
		 sb.append("<Solicitud><MunicipioSolicitud>008</MunicipioSolicitud>");
		 sb.append("<Titular><DatosPersonales>");
		 sb.append("<Nombre>Mickey</Nombre>");
		 sb.append("<Apellido1>Mouse</Apellido1>");
		 sb.append("</DatosPersonales></Titular>");
		 sb.append("<ProvinciaSolicitud>07</ProvinciaSolicitud>");
		 sb.append("</Solicitud></DatosEspecificos>");	 
		 XML_PET=sb.toString();
		 callBackOffice();		
	}
	
	   // @Test
		public void testSCDCPAJU2() {
			 COD_CERTIFICADO="SCDCPAJU";
			 StringBuilder sb = new StringBuilder();
			 sb.append("<DatosEspecificos xmlns=\"http://intermediacion.redsara.es/scsp/esquemas/datosespecificos\"><Solicitud>");
			 sb.append(" <Titular><DatosPersonales>");
			 sb.append("<Nombre>GUILLERMO</Nombre>");
			 sb.append(" <Particula1></Particula1>");
			 sb.append("<Apellido1>SIMONET</Apellido1>");
			 sb.append("<Particula2></Particula2>");
			 sb.append("<Apellido2>RAMON</Apellido2>");
			 sb.append("<FechaNacimiento>21/06/1987</FechaNacimiento>");
			 sb.append("</DatosPersonales>");
			 sb.append("<Documentacion>");
			 sb.append("<Tipo>NIF</Tipo>");
			 sb.append("<Valor>43186268L</Valor>");
			 sb.append("</Documentacion>");
			 sb.append("</Titular>");
			 sb.append("<MunicipioSolicitud>005</MunicipioSolicitud>");
			 sb.append("<ProvinciaSolicitud>07</ProvinciaSolicitud>");
			 sb.append("</Solicitud>");
			 sb.append("</DatosEspecificos>");
			 XML_PET=sb.toString();
			 callBackOffice();	
	
		}

	private void callBackOffice(){
		
		 try{ 
			 TransaccionSCSP ts = daobackoffice.procesaPeticion(COD_CERTIFICADO, XML_PET);
		     LOG.info("############## @callBackOffice ");
			 LOG.info("####### @setUp  id: {}", daobackoffice);
			 LOG.info("####### @setUp  Certificado: {}", COD_CERTIFICADO);
			 LOG.info("####### @setUp  Datos Especificos: {}", XML_PET);
			 printTransaccion(ts);
			 LOG.info("####### @exec  Ok!");
		 }catch(Exception e){
				printException(e);
		 }
	}
	
	private void printTransaccion(TransaccionSCSP ts) {
		    LOG.info("############## @data  TRANSACCION: {}", ts);
		 if(ts!=null){
			LOG.info("#######  id = {}", ts.getId());	 
			LOG.info("#######  valor= {}", ts.getValor());	
			LOG.info("#######  repuesta= {}",ts.getRepuesta());	
			LOG.info("#######  errorSOAP= {}",ts.getErrorSOAP());	
			LOG.info("#######  errorTRAMITE= {}",ts.getErrorTRAMITE());	
			LOG.info("#######  errorMensaje= {}",ts.getErrorMensaje());	
			LOG.info("############## ");
		 }
		
	}

	private void printException(Exception e){	
		
		 LOG.error("#################################");
		 LOG.error("#####     FALLO TEST       ######");
		 LOG.error("#################################");
				
		 LOG.error("##### Orige: {}", e.toString());
		 e.printStackTrace();
		 fail(" ------------- FALLO TEST!!!! " + e.toString());
	}
}
